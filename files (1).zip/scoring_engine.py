"""
scoring_engine.py — Weighted Attribute Scoring for Candidate Elements
======================================================================

The scoring engine is the analytical heart of the healing process.
Given a *reference fingerprint* (attributes stored in metadata) and a
*candidate fingerprint* (attributes extracted from a live DOM element),
it produces a composite confidence score in the range [0, 100].

Scoring algorithm overview
--------------------------
1. For each attribute tracked in ``SCORE_WEIGHTS``:
   a. Compute a per-attribute similarity in [0, 1] using the most
      appropriate comparison function (exact, fuzzy-token, set overlap).
   b. Multiply by the attribute's weight.
2. Sum all weighted contributions → raw score in [0, 100].
3. Apply dynamic-ID penalty if the candidate's ``id`` looks auto-generated.
4. Return the final score.

Fuzzy matching uses difflib's ``SequenceMatcher`` which is stdlib-only
and avoids an external dependency.  The ``rapidfuzz`` library can be
swapped in as a drop-in upgrade for better performance on large DOMs.
"""

from __future__ import annotations

import difflib
import logging
import re
from typing import Any

from HealingLibrary.core.constants import DYNAMIC_ID_PATTERNS, SCORE_WEIGHTS

logger = logging.getLogger(__name__)

# Pre-compile dynamic-ID patterns for speed.
_DYNAMIC_ID_RE: list[re.Pattern[str]] = [
    re.compile(p, re.IGNORECASE) for p in DYNAMIC_ID_PATTERNS
]


def _fuzzy_ratio(a: str, b: str) -> float:
    """Return a similarity ratio in [0, 1] between two strings.

    Uses ``difflib.SequenceMatcher`` (Gestalt pattern matching).
    Returns 0.0 if either string is empty.
    """
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, a.lower(), b.lower()).ratio()


def _token_set_ratio(a: str, b: str) -> float:
    """Token-set similarity: compare sorted token sets.

    Useful for CSS class lists where order may differ between snapshots.
    e.g. ``"btn primary large"`` vs ``"large btn primary"`` → 1.0
    """
    if not a or not b:
        return 0.0
    set_a = set(a.lower().split())
    set_b = set(b.lower().split())
    if not set_a or not set_b:
        return 0.0
    intersection = set_a & set_b
    union = set_a | set_b
    # Jaccard index weighted by the smaller set (penalises large additions)
    jaccard = len(intersection) / len(union)
    # Also compare as concatenated sorted strings for sequential similarity
    joined_a = " ".join(sorted(set_a))
    joined_b = " ".join(sorted(set_b))
    sequential = difflib.SequenceMatcher(None, joined_a, joined_b).ratio()
    return max(jaccard, sequential)


def _is_dynamic_id(id_value: str) -> bool:
    """Return True if *id_value* looks like an auto-generated dynamic ID."""
    if not id_value:
        return False
    return any(p.search(id_value) for p in _DYNAMIC_ID_RE)


def _score_attribute(attr_name: str, ref_val: str, cand_val: str) -> float:
    """Compute a per-attribute similarity score in [0, 1].

    Different attributes use different comparison strategies:

    * ``id``, ``name``, ``aria-label``, ``placeholder``, ``tag``:
      exact then fuzzy string match.
    * ``class``: token-set overlap (order-independent).
    * ``text``: fuzzy ratio (inner text may be truncated or wrapped).
    * ``xpath``, ``ancestor_path``: fuzzy ratio on path strings.
    """
    if not ref_val and not cand_val:
        return 0.0  # Neither side has this attribute — neutral, not positive

    if attr_name in {"id", "name", "tag", "aria-label", "placeholder"}:
        if ref_val == cand_val:
            return 1.0
        return _fuzzy_ratio(ref_val, cand_val) * 0.8  # partial credit

    if attr_name == "class":
        return _token_set_ratio(ref_val, cand_val)

    if attr_name in {"text", "xpath", "ancestor_path"}:
        return _fuzzy_ratio(ref_val, cand_val)

    # Fallback for any future attributes
    return _fuzzy_ratio(ref_val, cand_val)


def score_candidate(
    reference: dict[str, Any],
    candidate: dict[str, Any],
) -> float:
    """Compute a composite confidence score for a candidate element.

    Parameters
    ----------
    reference:
        Attribute dict loaded from ``MetadataManager`` (the last-known
        good fingerprint of the target element).
    candidate:
        Attribute dict extracted from a live DOM element by the scanner.

    Returns
    -------
    float
        Composite score in the range **[0, 100]**.  Higher is better.
    """
    total_weight = sum(SCORE_WEIGHTS.values())
    raw_score = 0.0

    for attr, weight in SCORE_WEIGHTS.items():
        ref_val = str(reference.get(attr, "")).strip()
        cand_val = str(candidate.get(attr, "")).strip()
        attr_score = _score_attribute(attr, ref_val, cand_val)
        contribution = attr_score * weight
        raw_score += contribution
        logger.debug(
            "  [score] %-15s  ref=%-30s  cand=%-30s  sim=%.2f  contrib=%.2f",
            attr,
            ref_val[:30],
            cand_val[:30],
            attr_score,
            contribution,
        )

    # Normalise to [0, 100]
    normalised = (raw_score / total_weight) * 100.0

    # --- Dynamic ID penalty ---
    # If the candidate has a dynamic-looking ID *and* the reference had a
    # stable ID, we reduce confidence because we don't want to anchor to
    # an ID that will break again on the next page load.
    cand_id = str(candidate.get("id", "")).strip()
    ref_id = str(reference.get("id", "")).strip()
    if cand_id and ref_id and _is_dynamic_id(cand_id) and not _is_dynamic_id(ref_id):
        penalty = SCORE_WEIGHTS["id"] * 0.5  # Halve the id weight as penalty
        normalised = max(0.0, normalised - penalty)
        logger.debug(
            "  [score] Dynamic-ID penalty applied (cand_id='%s'): -%.1f → %.2f",
            cand_id,
            penalty,
            normalised,
        )

    logger.debug("  [score] Final composite score: %.2f", normalised)
    return round(normalised, 2)


def rank_candidates(
    reference: dict[str, Any],
    candidates: list[dict[str, Any]],
) -> list[tuple[float, dict[str, Any]]]:
    """Score all *candidates* against *reference* and return a ranked list.

    Parameters
    ----------
    reference:
        Stored metadata fingerprint.
    candidates:
        List of attribute dicts from the DOM scanner.

    Returns
    -------
    list of (score, candidate) tuples, sorted descending by score.
    """
    scored = [
        (score_candidate(reference, c), c)
        for c in candidates
    ]
    scored.sort(key=lambda t: t[0], reverse=True)
    return scored
