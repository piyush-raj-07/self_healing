*** Settings ***
Documentation
...    Example Robot Framework test suite demonstrating HealingLibrary.
...
...    Prerequisites
...    -------------
...    1. pip install robotframework selenium robotframework-seleniumlibrary
...    2. pip install -e /path/to/healing_library   (or PYTHONPATH=.)
...    3. A compatible WebDriver (e.g. chromedriver) on your PATH.
...
...    Run:
...        robot --outputdir results examples/example_tests.robot

Library     SeleniumLibrary     timeout=10s     implicit_wait=0s
Library     HealingLibrary
...         metadata_path=${CURDIR}/locator_metadata.json
...         confidence_reject=40
...         confidence_warn=60
...         confidence_auto=80

Suite Setup       Open Browser    ${BASE_URL}    ${BROWSER}
Suite Teardown    Close All Browsers

*** Variables ***
${BASE_URL}     https://example-shop.com
${BROWSER}      chrome

# --- Locator aliases — change these when the real app's IDs shift ---
${LOC_EMAIL}          id=email
${LOC_PASSWORD}       id=password
${LOC_LOGIN_BTN}      id=login-btn
${LOC_SEARCH}         id=search-bar
${LOC_CHECKOUT}       css=button.checkout-btn
${LOC_STATUS_MSG}     id=status-msg

*** Test Cases ***

# =======================================================================
# Registration: run these once with good locators to seed the metadata
# =======================================================================

Seed Locator Metadata
    [Documentation]    Register all locators while they are healthy.
    ...                Re-run this test whenever the UI is redesigned
    ...                to refresh the fingerprints.
    [Tags]    seed    setup

    Go To    ${BASE_URL}/login

    Register Locator    ${LOC_EMAIL}        locator_key=email_field
    Register Locator    ${LOC_PASSWORD}     locator_key=password_field
    Register Locator    ${LOC_LOGIN_BTN}    locator_key=login_button

    Go To    ${BASE_URL}/shop

    Register Locator    ${LOC_SEARCH}       locator_key=search_input
    Register Locator    ${LOC_CHECKOUT}     locator_key=checkout_button

    Log    Locator metadata seeded successfully.

# =======================================================================
# Happy-path login — works even when locators drift
# =======================================================================

Login With Self-Healing Locators
    [Documentation]    Log in using HealingLibrary keywords.
    ...                If the original id= locators break (e.g. after a
    ...                front-end refactor), the library automatically
    ...                scans the DOM and heals them before retrying.
    [Tags]    smoke    login

    Go To    ${BASE_URL}/login

    # Heal Input Text: fills the field, healing if id=email is gone
    Heal Input Text
    ...    locator=${LOC_EMAIL}
    ...    text=testuser@example.com
    ...    locator_key=email_field

    Heal Input Text
    ...    locator=${LOC_PASSWORD}
    ...    text=S3cur3P@ss!
    ...    locator_key=password_field

    # Heal Click Element: clicks with JS fallback if overlapped
    Heal Click Element
    ...    locator=${LOC_LOGIN_BTN}
    ...    locator_key=login_button

    # Standard SeleniumLibrary assertion — no healing needed here
    Location Should Contain    /dashboard

# =======================================================================
# Search and add to cart — demonstrates Heal Find Element
# =======================================================================

Search For Product And Checkout
    [Documentation]    Search for a product and proceed to checkout.
    [Tags]    smoke    shopping

    Go To    ${BASE_URL}/shop

    Heal Input Text
    ...    locator=${LOC_SEARCH}
    ...    text=wireless headphones
    ...    locator_key=search_input

    # Press Enter via SeleniumLibrary directly (no healing needed)
    Press Keys    ${LOC_SEARCH}    RETURN

    # Click first result — using Heal Find Element to get the WebElement
    ${first_result}=    Heal Find Element
    ...    locator=css=.product-card:first-child .add-to-cart
    ...    locator_key=first_add_to_cart

    # Heal Click Element for checkout
    Heal Click Element
    ...    locator=${LOC_CHECKOUT}
    ...    locator_key=checkout_button

    # Read confirmation text with healing
    ${msg}=    Heal Get Text
    ...    locator=${LOC_STATUS_MSG}
    ...    locator_key=status_message

    Should Contain    ${msg}    order
    Log    Order confirmation: ${msg}

# =======================================================================
# Healing statistics report
# =======================================================================

Log Healing Statistics At End Of Suite
    [Documentation]    Print a summary of all auto-healed locators.
    [Tags]    reporting

    ${stats}=    Get Healing Statistics
    Log    \n===== Healing Statistics =====    console=True
    FOR    ${key}    IN    @{stats}
        Log    ${key}: heals=${stats}[${key}][heal_count]    console=True
    END

*** Keywords ***

# Re-usable composite keyword built on top of HealingLibrary
Login As
    [Documentation]    Log in with the supplied credentials using healed locators.
    [Arguments]    ${email}    ${password}
    Go To    ${BASE_URL}/login
    Heal Input Text    ${LOC_EMAIL}       ${email}     locator_key=email_field
    Heal Input Text    ${LOC_PASSWORD}    ${password}  locator_key=password_field
    Heal Click Element    ${LOC_LOGIN_BTN}             locator_key=login_button
    Location Should Contain    /dashboard
