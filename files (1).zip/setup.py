"""
setup.py — HealingLibrary package installer
============================================

Install in editable mode for development:

    pip install -e .

Install normally:

    pip install .
"""

from setuptools import find_packages, setup

setup(
    name="robotframework-healinglibrary",
    version="1.0.0",
    description="Self-healing Selenium locator library for Robot Framework",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Your Team",
    python_requires=">=3.9",
    packages=find_packages(exclude=["tests*", "examples*"]),
    install_requires=[
        "robotframework>=5.0",
        "robotframework-seleniumlibrary>=6.0",
        "selenium>=4.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-mock",
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Framework :: Robot Framework :: Library",
        "Topic :: Software Development :: Testing",
    ],
)
