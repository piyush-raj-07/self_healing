"""
healer.py — Self-Healing Orchestrator
======================================

``Healer`` is the top-level coordinator that wires together:

* Pre-healing environment checks (:mod:`pre_checks`)
* DOM scanning strategies (:mod:`dom_scanner`)
* Weighted attribute scoring (:mod:`scoring_engine`)
* Metadata persistence (:class:`MetadataManager`)

Healing flow
------------
::

    original locator fails
        ↓
    run_all_pre_checks()        ← ensure page is stable
        ↓
    load reference from MetadataManager
        ↓
    scan_for_candidates()       ← multi-strategy DOM search
        ↓
    rank_candidates()           ← score each against reference
        ↓
    apply confidence thresholds
        ├─ score < REJECT  → raise HealingError
        ├─ score < WARN    → warn log, return healed locator
        └─ score >= AUTO   → silent heal, return healed locator
        ↓
    record_healing()            ← persist new metadata
        ↓
    return (healed_locator, score)
"""

from __future__ import annotations

import logging
from typing import Any, Optional, Tuple

from selenium.webdriver.remote.webdriver import WebDriver

from HealingLibrary.core.constants import (
    CONFIDENCE_AUTO,
    CONFIDENCE_REJECT,
    CONFIDENCE_WARN,
)
from HealingLibrary.core.dom_scanner import extract_attributes, scan_for_candidates
from HealingLibrary.core.metadata_manager import MetadataManager
from HealingLibrary.core.pre_checks import run_all_pre_checks
from HealingLibrary.core.scoring_engine import rank_candidates

logger = logging.getLogger(__name__)


class HealingError(Exception):
    """Raised when the healer cannot find a confident replacement locator."""


class Healer:
    """Orchestrates the full self-healing cycle for a broken locator.

    Parameters
    ----------
    metadata_manager:
        Shared ``MetadataManager`` instance (owns the JSON store).
    confidence_reject:
        Override the reject threshold from ``constants.py``.
    confidence_warn:
        Override the warn threshold from ``constants.py``.
    confidence_auto:
        Override the auto-apply threshold from ``constants.py``.
    """

    def __init__(
        self,
        metadata_manager: MetadataManager,
        *,
        confidence_reject: float = CONFIDENCE_REJECT,
        confidence_warn: float = CONFIDENCE_WARN,
        confidence_auto: float = CONFIDENCE_AUTO,
    ) -> None:
        self._meta = metadata_manager
        self._reject = confidence_reject
        self._warn = confidence_warn
        self._auto = confidence_auto

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def heal(
        self,
        driver: WebDriver,
        locator_key: str,
        original_locator: str,
    ) -> Tuple[str, float]:
        """Attempt to heal a broken locator and return the replacement.

        Parameters
        ----------
        driver:
            Active WebDriver instance.
        locator_key:
            Human-readable alias used to look up stored metadata.
        original_locator:
            The locator string that failed (used for logging / fallback).

        Returns
        -------
        tuple
            ``(healed_locator, confidence_score)`` where *healed_locator*
            is a Robot Framework-compatible string (e.g. ``"xpath=…"``).

        Raises
        ------
        HealingError
            If no candidate scores above ``confidence_reject``.
        """
        logger.info(
            "healer: starting healing for key='%s', locator='%s'",
            locator_key,
            original_locator,
        )

        # 1. Run pre-healing environment checks
        pre_status = run_all_pre_checks(driver)
        if pre_status.get("modal_selector"):
            logger.warning(
                "healer: blocking modal detected ('%s') — healing may be unreliable",
                pre_status["modal_selector"],
            )

        # 2. Load stored reference fingerprint
        reference = self._meta.get(locator_key)
        if reference is None:
            raise HealingError(
                f"No stored metadata for locator key '{locator_key}'. "
                "Register the locator first using 'Register Locator'."
            )

        logger.debug("healer: reference fingerprint: %s", reference)

        # 3. Scan the live DOM for candidates
        candidates = scan_for_candidates(driver, reference)
        if not candidates:
            raise HealingError(
                f"DOM scan produced zero candidates for key='{locator_key}'."
            )

        # 4. Score and rank candidates
        ranked = rank_candidates(reference, candidates)
        best_score, best_candidate = ranked[0]

        logger.info(
            "healer: best candidate score=%.2f (top 3: %s)",
            best_score,
            [(s, c.get("tag"), c.get("id"), c.get("text", "")[:30]) for s, c in ranked[:3]],
        )

        # 5. Apply confidence thresholds
        if best_score < self._reject:
            raise HealingError(
                f"Best candidate score ({best_score:.1f}) is below reject "
                f"threshold ({self._reject}). Healing refused for '{locator_key}'."
            )

        if best_score < self._warn:
            logger.warning(
                "healer: LOW CONFIDENCE heal for '%s' (score=%.1f < warn=%.1f). "
                "Verify the healed locator manually.",
                locator_key,
                best_score,
                self._warn,
            )
        elif best_score < self._auto:
            logger.warning(
                "healer: MEDIUM CONFIDENCE heal for '%s' (score=%.1f). Proceeding.",
                locator_key,
                best_score,
            )
        else:
            logger.info(
                "healer: HIGH CONFIDENCE heal for '%s' (score=%.1f). Applying silently.",
                locator_key,
                best_score,
            )

        # 6. Build the healed locator string
        healed_locator = self._build_locator(best_candidate)

        # 7. Persist the healing result back to metadata
        self._meta.record_healing(
            locator_key=locator_key,
            healed_locator=healed_locator,
            new_attributes={
                k: v for k, v in best_candidate.items()
                if not k.startswith("_")
            },
        )

        logger.info(
            "healer: healed '%s' → '%s' (score=%.2f)",
            locator_key,
            healed_locator,
            best_score,
        )
        return healed_locator, best_score

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_locator(candidate: dict[str, Any]) -> str:
        """Build the most stable Robot Framework locator from a candidate.

        Priority: id → name → aria-label → xpath

        Parameters
        ----------
        candidate:
            Attribute dict from the DOM scanner.

        Returns
        -------
        str
            A Robot Framework locator string, e.g. ``"id=submit-btn"``.
        """
        eid = candidate.get("id", "").strip()
        if eid:
            return f"id={eid}"

        name = candidate.get("name", "").strip()
        if name:
            return f"name={name}"

        aria = candidate.get("aria-label", "").strip()
        if aria:
            return f"xpath=//*[@aria-label='{aria}']"

        xpath = candidate.get("xpath", "").strip()
        if xpath:
            return f"xpath={xpath}"

        # Last resort: build a CSS selector from tag + class
        tag = candidate.get("tag", "div")
        css_class = candidate.get("class", "").strip()
        first_class = css_class.split()[0] if css_class else ""
        if first_class:
            return f"css={tag}.{first_class}"

        return f"xpath=//{tag}"
