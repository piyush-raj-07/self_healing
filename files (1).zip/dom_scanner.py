"""
dom_scanner.py — Multi-Strategy DOM Element Discovery
======================================================

Implements five escalating scan strategies, each progressively more
expensive but more thorough:

1. **Exact attribute lookup** — targeted ``find_elements`` calls using
   the most discriminating reference attributes (id, name, aria-label).
2. **Filtered DOM scan** — iterate over a curated set of interactive
   HTML tags and compare attributes.
3. **Full DOM scan** — walk every element up to ``MAX_DOM_SCAN_ELEMENTS``
   and fingerprint each one.
4. **Iframe scan** — switch into each iframe in turn and repeat the
   filtered scan inside it.
5. **Shadow DOM scan** — use JavaScript to pierce shadow roots and
   collect elements that are otherwise invisible to WebDriver.

All strategies return the same data structure: a list of *candidate
dicts* containing the element's attributes plus a ``_element`` key
holding the live ``WebElement`` reference.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement

from HealingLibrary.core.constants import MAX_DOM_SCAN_ELEMENTS, SCANNABLE_TAGS

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Attribute extraction helpers
# ---------------------------------------------------------------------------

_JS_GET_ANCESTOR_PATH = (
    "(function(el) {"
    "  var parts = [];"
    "  while (el && el.nodeType === Node.ELEMENT_NODE && parts.length < 4) {"
    "    var seg = el.tagName.toLowerCase();"
    "    if (el.id) { seg += '#' + el.id; }"
    "    else if (el.className) {"
    r"      var cls = el.className.trim().split(/\s+/).slice(0, 2).join('.');"
    "      if (cls) seg += '.' + cls;"
    "    }"
    "    parts.unshift(seg);"
    "    el = el.parentElement;"
    "  }"
    "  return parts.join(' > ');"
    "})(arguments[0]);"
)

_JS_GET_XPATH = """
(function(el) {
    if (el.id) return '//' + el.tagName.toLowerCase() + '[@id="' + el.id + '"]';
    var parts = [];
    while (el && el.nodeType === Node.ELEMENT_NODE) {
        var idx = 1;
        var sib = el.previousSibling;
        while (sib) {
            if (sib.nodeType === Node.ELEMENT_NODE && sib.tagName === el.tagName) idx++;
            sib = sib.previousSibling;
        }
        var seg = el.tagName.toLowerCase();
        if (idx > 1) seg += '[' + idx + ']';
        parts.unshift(seg);
        el = el.parentElement;
    }
    return '/' + parts.join('/');
})(arguments[0]);
"""

_JS_SHADOW_SCAN = """
(function() {
    var results = [];
    var tags = arguments[0];
    function walk(root) {
        var nodes = root.querySelectorAll(tags.join(','));
        nodes.forEach(function(el) {
            results.push({
                tag:         el.tagName ? el.tagName.toLowerCase() : '',
                id:          el.id || '',
                name:        el.getAttribute('name') || '',
                text:        (el.innerText || el.textContent || '').trim().substring(0, 200),
                'class':     el.className || '',
                'aria-label': el.getAttribute('aria-label') || '',
                placeholder: el.getAttribute('placeholder') || '',
                outerHTML:   el.outerHTML.substring(0, 300)
            });
        });
        // recurse into shadow roots
        root.querySelectorAll('*').forEach(function(el) {
            if (el.shadowRoot) walk(el.shadowRoot);
        });
    }
    walk(document);
    return results;
})();
"""


def extract_attributes(driver: WebDriver, element: WebElement) -> dict[str, Any]:
    """Extract a normalised attribute fingerprint from a live *element*.

    Parameters
    ----------
    driver:
        The active WebDriver instance (needed for JS execution).
    element:
        The ``WebElement`` to fingerprint.

    Returns
    -------
    dict
        Keys: ``tag``, ``id``, ``name``, ``text``, ``class``,
        ``aria-label``, ``placeholder``, ``xpath``, ``ancestor_path``.
        Values are always strings (empty string when absent).
    """
    try:
        tag = (element.tag_name or "").lower()
        eid = element.get_attribute("id") or ""
        name = element.get_attribute("name") or ""
        text = (element.text or "").strip()[:200]
        css_class = element.get_attribute("class") or ""
        aria_label = element.get_attribute("aria-label") or ""
        placeholder = element.get_attribute("placeholder") or ""

        # These require JS execution — wrap in try/except individually.
        try:
            xpath = driver.execute_script(_JS_GET_XPATH, element) or ""
        except Exception:
            xpath = ""
        try:
            ancestor_path = driver.execute_script(_JS_GET_ANCESTOR_PATH, element) or ""
        except Exception:
            ancestor_path = ""

        return {
            "tag":          tag,
            "id":           eid,
            "name":         name,
            "text":         text,
            "class":        css_class,
            "aria-label":   aria_label,
            "placeholder":  placeholder,
            "xpath":        xpath,
            "ancestor_path": ancestor_path,
            "_element":     element,
        }
    except Exception as exc:
        logger.debug("extract_attributes: error on element — %s", exc)
        return {"_element": element}


# ---------------------------------------------------------------------------
# Strategy 1: Exact attribute lookup
# ---------------------------------------------------------------------------

def strategy_exact_attributes(
    driver: WebDriver,
    reference: dict[str, Any],
) -> list[dict[str, Any]]:
    """Search for elements using the most discriminating stored attributes.

    Performs direct ``find_elements`` calls for id, name, and aria-label.
    This is the fastest strategy and should be tried first.

    Returns
    -------
    list of candidate attribute dicts (may be empty).
    """
    candidates: list[dict[str, Any]] = []

    def _find(by: str, value: str) -> None:
        if not value:
            return
        try:
            elements = driver.find_elements(by, value)
            for el in elements:
                attrs = extract_attributes(driver, el)
                candidates.append(attrs)
                logger.debug("strategy_exact: found element by %s='%s'", by, value)
        except Exception as exc:
            logger.debug("strategy_exact: error for %s='%s': %s", by, value, exc)

    _find(By.ID, reference.get("id", ""))
    _find(By.NAME, reference.get("name", ""))
    _find(By.XPATH, f"//*[@aria-label='{reference.get('aria-label', '')}']")
    _find(By.XPATH, f"//*[@placeholder='{reference.get('placeholder', '')}']")

    return candidates


# ---------------------------------------------------------------------------
# Strategy 2: Filtered DOM scan (interactive tags only)
# ---------------------------------------------------------------------------

def strategy_filtered_dom(
    driver: WebDriver,
    reference: dict[str, Any],
) -> list[dict[str, Any]]:
    """Iterate over interactive elements and collect attribute fingerprints.

    Limits scanning to ``SCANNABLE_TAGS`` for a reasonable performance
    budget.  A reference tag hint further narrows the search when available.

    Returns
    -------
    list of candidate attribute dicts.
    """
    ref_tag = reference.get("tag", "")
    tags = [ref_tag] if ref_tag and ref_tag in SCANNABLE_TAGS else SCANNABLE_TAGS
    candidates: list[dict[str, Any]] = []

    for tag in tags:
        try:
            elements = driver.find_elements(By.TAG_NAME, tag)
            for el in elements:
                attrs = extract_attributes(driver, el)
                candidates.append(attrs)
        except Exception as exc:
            logger.debug("strategy_filtered_dom: error for tag '%s': %s", tag, exc)

    logger.debug("strategy_filtered_dom: collected %d candidates", len(candidates))
    return candidates


# ---------------------------------------------------------------------------
# Strategy 3: Full DOM scan
# ---------------------------------------------------------------------------

def strategy_full_dom(driver: WebDriver) -> list[dict[str, Any]]:
    """Walk every element in the DOM up to ``MAX_DOM_SCAN_ELEMENTS``.

    Expensive — use only when strategies 1 & 2 fail.

    Returns
    -------
    list of candidate attribute dicts.
    """
    candidates: list[dict[str, Any]] = []
    try:
        elements = driver.find_elements(By.XPATH, "//*")[:MAX_DOM_SCAN_ELEMENTS]
        for el in elements:
            attrs = extract_attributes(driver, el)
            candidates.append(attrs)
    except Exception as exc:
        logger.debug("strategy_full_dom: error — %s", exc)
    logger.debug("strategy_full_dom: collected %d candidates", len(candidates))
    return candidates


# ---------------------------------------------------------------------------
# Strategy 4: Iframe scan
# ---------------------------------------------------------------------------

def strategy_iframe_scan(
    driver: WebDriver,
    reference: dict[str, Any],
) -> list[dict[str, Any]]:
    """Switch into each iframe and repeat the filtered scan inside it.

    Restores the default content context after scanning each frame.

    Returns
    -------
    list of candidate attribute dicts annotated with ``_iframe_index``.
    """
    candidates: list[dict[str, Any]] = []
    try:
        iframes = driver.find_elements(By.TAG_NAME, "iframe")
    except Exception:
        return candidates

    for idx, iframe in enumerate(iframes):
        try:
            driver.switch_to.frame(iframe)
            logger.debug("strategy_iframe_scan: scanning iframe %d", idx)
            inner = strategy_filtered_dom(driver, reference)
            for attrs in inner:
                attrs["_iframe_index"] = idx
            candidates.extend(inner)
        except Exception as exc:
            logger.debug("strategy_iframe_scan: error in iframe %d — %s", idx, exc)
        finally:
            driver.switch_to.default_content()

    logger.debug("strategy_iframe_scan: collected %d candidates", len(candidates))
    return candidates


# ---------------------------------------------------------------------------
# Strategy 5: Shadow DOM scan (JavaScript-based)
# ---------------------------------------------------------------------------

def strategy_shadow_dom(driver: WebDriver) -> list[dict[str, Any]]:
    """Use JavaScript to pierce shadow roots and collect candidates.

    Returns lightweight dicts (no live element reference) because
    shadow-DOM elements cannot be directly returned by ``execute_script``
    in all WebDriver implementations.  The caller will need to re-locate
    via the stored attributes if a match is found.

    Returns
    -------
    list of candidate attribute dicts (``_element`` key is absent).
    """
    try:
        raw: list[dict[str, Any]] = driver.execute_script(
            _JS_SHADOW_SCAN, SCANNABLE_TAGS
        )
        candidates = [{**r, "_shadow": True} for r in (raw or [])]
        logger.debug("strategy_shadow_dom: collected %d candidates", len(candidates))
        return candidates
    except Exception as exc:
        logger.debug("strategy_shadow_dom: error — %s", exc)
        return []


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------

def scan_for_candidates(
    driver: WebDriver,
    reference: dict[str, Any],
    *,
    include_iframes: bool = True,
    include_shadow: bool = True,
) -> list[dict[str, Any]]:
    """Run all strategies and return a de-duplicated list of candidates.

    Strategies are run in order of increasing cost.  Each strategy's
    results are appended; de-duplication is done by element object
    identity (``_element`` reference) to avoid scoring the same node
    multiple times.

    Parameters
    ----------
    driver:
        Active WebDriver instance.
    reference:
        Stored metadata dict for the failing locator.
    include_iframes:
        Whether to descend into iframes (default: True).
    include_shadow:
        Whether to pierce shadow DOM via JS (default: True).

    Returns
    -------
    list of unique candidate attribute dicts.
    """
    all_candidates: list[dict[str, Any]] = []
    seen_elements: set[int] = set()

    def _add(batch: list[dict[str, Any]]) -> None:
        for c in batch:
            el = c.get("_element")
            if el is not None:
                eid = id(el)
                if eid in seen_elements:
                    continue
                seen_elements.add(eid)
            all_candidates.append(c)

    logger.debug("dom_scanner: starting exact-attribute strategy")
    _add(strategy_exact_attributes(driver, reference))

    logger.debug("dom_scanner: starting filtered-DOM strategy")
    _add(strategy_filtered_dom(driver, reference))

    if not all_candidates:
        logger.debug("dom_scanner: no candidates yet, running full-DOM strategy")
        _add(strategy_full_dom(driver))

    if include_iframes:
        logger.debug("dom_scanner: starting iframe strategy")
        _add(strategy_iframe_scan(driver, reference))

    if include_shadow:
        logger.debug("dom_scanner: starting shadow-DOM strategy")
        _add(strategy_shadow_dom(driver))

    logger.info("dom_scanner: %d unique candidates collected", len(all_candidates))
    return all_candidates
