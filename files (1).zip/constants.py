"""
constants.py — Global configuration knobs for HealingLibrary
=============================================================

All tunable parameters live here so that callers can override them
without touching algorithmic code.  Import this module wherever you
need a configuration value; never hard-code magic numbers elsewhere.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Confidence thresholds
# ---------------------------------------------------------------------------

#: Minimum score (0-100) required to automatically apply a healed locator.
#: Below this value the healing attempt is rejected entirely.
CONFIDENCE_REJECT: float = 40.0

#: Scores in [CONFIDENCE_WARN, CONFIDENCE_AUTO) trigger a warning log but
#: still allow the healed locator to be used.
CONFIDENCE_WARN: float = 60.0

#: Scores >= CONFIDENCE_AUTO are applied silently (high confidence).
CONFIDENCE_AUTO: float = 80.0

# ---------------------------------------------------------------------------
# Scoring weights — must sum to 100 for intuitive percentage interpretation
# ---------------------------------------------------------------------------

#: Attribute name → weight contribution to the composite score.
SCORE_WEIGHTS: dict[str, float] = {
    "id":           20.0,
    "name":         15.0,
    "text":         15.0,
    "aria-label":   12.0,
    "placeholder":  10.0,
    "class":         8.0,
    "tag":           8.0,
    "xpath":         7.0,
    "ancestor_path": 5.0,
}

#: IDs that match this pattern are considered auto-generated/dynamic and
#: have their id-score contribution halved.
DYNAMIC_ID_PATTERNS: list[str] = [
    r"^[a-f0-9]{8}-[a-f0-9]{4}-",          # UUID-style
    r"\d{6,}",                               # Long numeric suffix
    r"^(ember|react|ng|vue)[0-9]+$",        # SPA framework IDs
    r"^[a-z]{1,3}\d{4,}$",                  # Short prefix + long digits
]

# ---------------------------------------------------------------------------
# Retry / timing
# ---------------------------------------------------------------------------

#: Number of times to retry a click/input after healing before giving up.
DEFAULT_RETRY_COUNT: int = 3

#: Seconds to wait between retries.
DEFAULT_RETRY_DELAY: float = 0.5

#: Maximum seconds to wait for page load / overlay to disappear.
PAGE_LOAD_TIMEOUT: float = 15.0

#: CSS selectors that indicate a loading overlay is blocking the page.
OVERLAY_SELECTORS: list[str] = [
    ".loading",
    ".loader",
    ".spinner",
    "[data-loading]",
    ".overlay",
    "#loading-overlay",
    ".sk-spinner",
    ".nprogress-busy",
]

#: CSS selectors for common modal/dialog containers.
MODAL_SELECTORS: list[str] = [
    ".modal.show",
    "[role='dialog']:not([aria-hidden='true'])",
    ".dialog--open",
    ".popup--active",
]

# ---------------------------------------------------------------------------
# DOM scanning
# ---------------------------------------------------------------------------

#: Maximum number of DOM elements to evaluate during a full scan.
#: Increase for very large pages at the cost of performance.
MAX_DOM_SCAN_ELEMENTS: int = 5_000

#: HTML tag names worth scanning when doing a filtered pass.
SCANNABLE_TAGS: list[str] = [
    "input", "button", "a", "select", "textarea",
    "label", "span", "div", "li", "td", "th",
]

# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------

#: Default file name for stored locator metadata (relative to CWD).
DEFAULT_METADATA_FILE: str = "locator_metadata.json"

#: Pretty-print JSON with this indent for human readability.
METADATA_JSON_INDENT: int = 2
