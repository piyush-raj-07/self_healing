"""
test_metadata_manager.py — Unit Tests for MetadataManager
==========================================================

Run with:  pytest tests/ -v
"""

from __future__ import annotations

import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from HealingLibrary.core.metadata_manager import MetadataManager


@pytest.fixture
def tmp_metadata(tmp_path):
    """Return a MetadataManager backed by a temporary JSON file."""
    path = str(tmp_path / "test_metadata.json")
    return MetadataManager(path=path), path


class TestMetadataManagerRegister:
    def test_register_creates_entry(self, tmp_metadata):
        mgr, path = tmp_metadata
        mgr.register("login_btn", "id=login-btn", {"id": "login-btn", "tag": "button", "text": "Log In"})

        entry = mgr.get("login_btn")
        assert entry is not None
        assert entry["original_locator"] == "id=login-btn"
        assert entry["id"] == "login-btn"
        assert entry["heal_count"] == 0

    def test_register_persists_to_disk(self, tmp_metadata):
        mgr, path = tmp_metadata
        mgr.register("btn", "id=btn", {"id": "btn", "tag": "button"})

        with open(path) as f:
            data = json.load(f)
        assert "btn" in data

    def test_register_updates_existing_entry(self, tmp_metadata):
        mgr, path = tmp_metadata
        mgr.register("btn", "id=btn", {"id": "btn", "text": "old text"})
        mgr.register("btn", "id=btn", {"id": "btn", "text": "new text"})

        entry = mgr.get("btn")
        assert entry["text"] == "new text"
        assert entry["heal_count"] == 0  # heal_count should not reset


class TestMetadataManagerRecordHealing:
    def test_record_healing_increments_count(self, tmp_metadata):
        mgr, _ = tmp_metadata
        mgr.register("btn", "id=btn", {"id": "btn", "tag": "button"})
        mgr.record_healing("btn", "xpath=//button[@name='submit']", {"name": "submit"})

        entry = mgr.get("btn")
        assert entry["heal_count"] == 1
        assert entry["healed_locator"] == "xpath=//button[@name='submit']"
        assert entry["last_healed"] is not None

    def test_second_healing_increments_further(self, tmp_metadata):
        mgr, _ = tmp_metadata
        mgr.register("btn", "id=btn", {"id": "btn"})
        mgr.record_healing("btn", "xpath=//button[1]", {})
        mgr.record_healing("btn", "name=submit", {})

        assert mgr.get("btn")["heal_count"] == 2

    def test_record_healing_on_unknown_key_creates_entry(self, tmp_metadata):
        mgr, _ = tmp_metadata
        # Should not raise — creates a minimal entry instead
        mgr.record_healing("unknown_key", "id=something", {})
        assert mgr.get("unknown_key") is not None


class TestMetadataManagerLoad:
    def test_missing_file_starts_empty(self, tmp_path):
        path = str(tmp_path / "nonexistent.json")
        mgr = MetadataManager(path=path)
        assert mgr.all_entries() == {}

    def test_corrupt_file_starts_empty(self, tmp_path):
        path = str(tmp_path / "bad.json")
        with open(path, "w") as f:
            f.write("NOT VALID JSON {{{{")
        mgr = MetadataManager(path=path)
        assert mgr.all_entries() == {}

    def test_existing_file_loaded_correctly(self, tmp_path):
        path = str(tmp_path / "meta.json")
        data = {
            "my_btn": {
                "original_locator": "id=x",
                "tag": "button",
                "id": "x",
                "name": "",
                "text": "Click",
                "class": "",
                "aria-label": "",
                "placeholder": "",
                "xpath": "",
                "ancestor_path": "",
                "healed_locator": None,
                "heal_count": 2,
                "last_healed": "2024-01-01T00:00:00+00:00",
            }
        }
        with open(path, "w") as f:
            json.dump(data, f)

        mgr = MetadataManager(path=path)
        entry = mgr.get("my_btn")
        assert entry is not None
        assert entry["heal_count"] == 2
