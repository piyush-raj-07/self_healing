# HealingLibrary — Self-Healing Locator Library for Robot Framework

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue)](https://python.org)
[![Robot Framework](https://img.shields.io/badge/Robot%20Framework-5%2B-orange)](https://robotframework.org)

A **production-ready, drop-in Robot Framework library** that transparently repairs broken
Selenium locators at runtime. When a locator fails, the library scans the live DOM using
five escalating strategies, scores every candidate with a weighted fingerprint algorithm,
and heals the locator — all within a single keyword call.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Package Structure](#package-structure)
3. [Installation](#installation)
4. [Quick Start](#quick-start)
5. [Healing Flow (Step-by-Step)](#healing-flow)
6. [Keywords Reference](#keywords-reference)
7. [Metadata File Format](#metadata-file-format)
8. [Confidence Thresholds](#confidence-thresholds)
9. [Scoring Algorithm](#scoring-algorithm)
10. [DOM Scanning Strategies](#dom-scanning-strategies)
11. [Configuration Reference](#configuration-reference)
12. [Extending the Library](#extending-the-library)
13. [Running Tests](#running-tests)

---

## Architecture Overview

```
HealingLibrary (Robot Framework entry point)
├── MetadataManager        ← JSON-backed fingerprint store
├── Healer                 ← Orchestrates the healing cycle
│   ├── pre_checks         ← Page load, overlays, modals, iframe reset
│   ├── dom_scanner        ← 5-strategy element discovery
│   └── scoring_engine     ← Weighted attribute comparison
└── utils                  ← retry, scroll, JS click, locator parser
```

The library is **library-scope = SUITE**, meaning one instance per test suite shares
the metadata store and writes it back atomically after each heal.

---

## Package Structure

```
healing_library/
├── HealingLibrary/
│   ├── __init__.py              ← Public package entry point
│   ├── library.py               ← Robot Framework keyword class
│   ├── core/
│   │   ├── constants.py         ← All tunable parameters
│   │   ├── metadata_manager.py  ← JSON metadata CRUD
│   │   ├── healer.py            ← Healing orchestrator
│   │   ├── dom_scanner.py       ← Multi-strategy DOM scanning
│   │   ├── pre_checks.py        ← Pre-healing environment checks
│   │   └── scoring_engine.py    ← Weighted attribute scoring
│   └── utils/
│       └── utils.py             ← Shared helpers
├── examples/
│   ├── example_tests.robot      ← Full Robot Framework example
│   └── locator_metadata.json    ← Sample metadata seed file
├── tests/
│   ├── test_scoring_engine.py
│   └── test_metadata_manager.py
├── setup.py
└── README.md
```

---

## Installation

```bash
# From the project root
pip install -e .

# Or add to your automation repo directly (no pip install required)
# Just ensure the HealingLibrary/ directory is on your PYTHONPATH
export PYTHONPATH=/path/to/healing_library:$PYTHONPATH
```

**Dependencies** (installed automatically):

| Package | Version |
|---|---|
| robotframework | >= 5.0 |
| robotframework-seleniumlibrary | >= 6.0 |
| selenium | >= 4.0 |

---

## Quick Start

### Step 1 — Import the library

```robotframework
Library     SeleniumLibrary
Library     HealingLibrary
...         metadata_path=${CURDIR}/locator_metadata.json
...         confidence_reject=40
...         confidence_warn=60
...         confidence_auto=80
```

### Step 2 — Seed the metadata (once, while locators work)

```robotframework
Seed Locators
    Open Browser    https://myapp.com/login    chrome
    Register Locator    id=email        locator_key=email_field
    Register Locator    id=login-btn    locator_key=login_button
    Close Browser
```

### Step 3 — Use healing keywords in your tests

```robotframework
Login Test
    Open Browser    https://myapp.com/login    chrome
    Heal Input Text     id=email        user@example.com    locator_key=email_field
    Heal Click Element  id=login-btn                        locator_key=login_button
    Location Should Contain    /dashboard
```

If the front-end team renames `id=email` to `id=user-email`, the library
automatically scans the DOM, finds the closest matching element, and retries —
with no test code change required.

---

## Healing Flow

```
 Heal Click Element called
        │
        ▼
 1. Try original locator  ──────────────────────── OK ──→ click and return
        │ FAIL
        ▼
 2. Pre-healing checks
    ├── wait for document.readyState == 'complete'
    ├── wait for overlay/spinner to vanish
    ├── dismiss native alerts
    ├── detect blocking modals (warn only)
    └── reset driver to default content (safety)
        │
        ▼
 3. Load reference fingerprint from metadata JSON
        │ (NoSuchKey) ──────────────────────────── → raise HealingError
        ▼
 4. DOM scan (escalating strategies)
    ├── Strategy 1: exact attribute lookup (id, name, aria-label)
    ├── Strategy 2: filtered DOM scan (interactive tags only)
    ├── Strategy 3: full DOM scan (up to 5000 elements)
    ├── Strategy 4: iframe scan (switch + scan each frame)
    └── Strategy 5: shadow DOM scan (JS pierce)
        │
        ▼
 5. Score every candidate (weighted, 0–100)
        │
        ▼
 6. Confidence gate
    ├── score < 40   → raise HealingError ("reject")
    ├── score < 60   → warn log, proceed
    └── score >= 80  → silent heal
        │
        ▼
 7. Persist healed locator + updated fingerprint to JSON
        │
        ▼
 8. Retry interaction with healed locator (up to 3×)
        │ FAIL ──────────────────────────────────── → propagate exception
        ▼
   return / keyword completes
```

---

## Keywords Reference

| Keyword | Arguments | Returns | Description |
|---|---|---|---|
| `Register Locator` | `locator`, `locator_key=` | — | Snapshot element fingerprint into metadata |
| `Heal Find Element` | `locator`, `locator_key=` | WebElement | Find element with healing |
| `Heal Click Element` | `locator`, `locator_key=`, `js_fallback=True` | — | Click with healing + JS fallback |
| `Heal Input Text` | `locator`, `text`, `locator_key=`, `clear_first=True` | — | Type text with healing |
| `Heal Get Text` | `locator`, `locator_key=` | str | Get visible text with healing |
| `Heal Get Attribute` | `locator`, `attribute`, `locator_key=` | str | Get DOM attribute with healing |
| `Get Healing Statistics` | — | dict | Summary of all healing activity |

---

## Metadata File Format

```json
{
  "login_button": {
    "original_locator": "id=login-btn",
    "tag":              "button",
    "id":               "login-btn",
    "name":             "",
    "text":             "Log In",
    "class":            "btn btn-primary btn-lg",
    "aria-label":       "Log in to your account",
    "placeholder":      "",
    "xpath":            "//button[@id='login-btn']",
    "ancestor_path":    "form#login-form > div.actions",
    "healed_locator":   null,
    "heal_count":       0,
    "last_healed":      null
  }
}
```

After a successful healing, the library updates the entry automatically:

```json
{
  "login_button": {
    "healed_locator":  "xpath=//button[@aria-label='Log in to your account']",
    "heal_count":      1,
    "last_healed":     "2025-03-15T10:22:07+00:00",
    ...
  }
}
```

---

## Confidence Thresholds

| Score Range | Behaviour |
|---|---|
| ≥ 80 | **AUTO HEAL** — applied silently, no warning logged |
| 60 – 79 | **WARN** — healed but a warning is logged for review |
| 40 – 59 | **LOW** — healed with a warning; validate manually |
| < 40 | **REJECT** — `HealingError` raised, test fails |

Override at import time:

```robotframework
Library    HealingLibrary
...        confidence_reject=35
...        confidence_warn=55
...        confidence_auto=75
```

---

## Scoring Algorithm

Each candidate is scored against the stored reference fingerprint using
a **weighted attribute comparison**:

| Attribute | Weight | Comparison Method |
|---|---|---|
| `id` | 20 | Exact + fuzzy; halved if ID is dynamic |
| `name` | 15 | Exact + fuzzy |
| `text` | 15 | Fuzzy ratio |
| `aria-label` | 12 | Exact + fuzzy |
| `placeholder` | 10 | Exact + fuzzy |
| `class` | 8 | Token-set (order-independent) |
| `tag` | 8 | Exact + fuzzy |
| `xpath` | 7 | Fuzzy ratio |
| `ancestor_path` | 5 | Fuzzy ratio |
| **Total** | **100** | |

**Dynamic ID detection**: IDs matching patterns like `ember1234`, UUIDs,
or `react99` receive a 50% id-weight penalty to avoid re-anchoring to
another auto-generated ID.

---

## DOM Scanning Strategies

```
Strategy 1: Exact attribute lookup     → fastest, very targeted
Strategy 2: Filtered DOM scan          → interactive tags only
Strategy 3: Full DOM scan              → up to 5000 elements
Strategy 4: Iframe scan                → switch into each frame
Strategy 5: Shadow DOM scan (JS)       → pierce shadow roots
```

Strategies 1 and 2 run unconditionally.  Strategy 3 runs only if the first
two found zero candidates.  Strategies 4 and 5 run in parallel with 3.

---

## Configuration Reference

All constants live in `HealingLibrary/core/constants.py`:

```python
CONFIDENCE_REJECT      = 40.0     # Below → refuse heal
CONFIDENCE_WARN        = 60.0     # Below → warn log
CONFIDENCE_AUTO        = 80.0     # Above → silent heal

SCORE_WEIGHTS          = { "id": 20, "name": 15, ... }

DYNAMIC_ID_PATTERNS    = [r"^ember\d+", r"\d{6,}", ...]

DEFAULT_RETRY_COUNT    = 3        # Retries after healing
DEFAULT_RETRY_DELAY    = 0.5      # Seconds between retries

PAGE_LOAD_TIMEOUT      = 15.0     # Seconds to wait for page/overlay
MAX_DOM_SCAN_ELEMENTS  = 5_000    # Cap on full DOM scan

OVERLAY_SELECTORS      = [".loading", ".spinner", ...]
MODAL_SELECTORS        = [".modal.show", "[role='dialog']", ...]
```

---

## Extending the Library

### Add an LLM healing strategy

```python
# HealingLibrary/core/llm_healer.py
from anthropic import Anthropic

def llm_suggest_locator(page_source: str, reference: dict) -> str:
    client = Anthropic()
    prompt = f"""
    The locator {reference['original_locator']} broke.
    Reference fingerprint: {reference}
    Page HTML (truncated): {page_source[:4000]}

    Return only a single Robot Framework locator string.
    """
    message = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=100,
        messages=[{"role": "user", "content": prompt}]
    )
    return message.content[0].text.strip()
```

Then call it in `healer.py` as a final fallback before raising `HealingError`.

### Add vector-database similarity search

```python
# Store element fingerprints as embeddings
import chromadb

collection = chromadb.Client().create_collection("locators")
collection.add(
    documents=[json.dumps(attrs)],
    ids=[locator_key],
)

# Query at heal time
results = collection.query(query_texts=[json.dumps(reference)], n_results=5)
```

### Add custom scoring attributes

Edit `SCORE_WEIGHTS` in `constants.py` and update `_score_attribute` in
`scoring_engine.py` to handle the new key.

---

## Running Tests

```bash
# Install dev extras
pip install -e ".[dev]"

# Run unit tests
pytest tests/ -v

# Run example Robot Framework suite (requires a running browser)
robot --outputdir results examples/example_tests.robot
```

---

## Logging

All modules use Python's standard `logging` library under the
`HealingLibrary.*` namespace.  To see debug output:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

Or in Robot Framework:

```robotframework
*** Settings ***
Library    HealingLibrary    metadata_path=locator_metadata.json

*** Test Cases ***
Debug Example
    Set Log Level    DEBUG
    Heal Click Element    id=btn    locator_key=my_button
```
