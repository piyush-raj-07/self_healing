"""
library.py — HealingLibrary Robot Framework Keyword Class
==========================================================

This module exposes the Robot Framework keywords.  Import this class
in your test suite:

.. code-block:: robotframework

    Library    HealingLibrary    metadata_path=locator_metadata.json

All public methods decorated with ``@keyword`` (via naming convention
or explicit decorator) become available as Robot Framework keywords.

Keyword summary
---------------
* ``Register Locator`` — snapshot an element's attributes into metadata.
* ``Heal Click Element`` — click with automatic locator healing on failure.
* ``Heal Input Text`` — type text with automatic locator healing on failure.
* ``Heal Get Text`` — retrieve text with automatic locator healing on failure.
* ``Heal Find Element`` — generic element lookup with healing (returns element).
* ``Get Healing Statistics`` — return a dict of heal counts from metadata.

Interaction model
-----------------
Each ``Heal *`` keyword:

1. Attempts the original locator using SeleniumLibrary's driver.
2. On ``NoSuchElementException`` (or any Selenium exception), triggers
   the full heal cycle via :class:`~HealingLibrary.core.healer.Healer`.
3. Retries the action with the healed locator.
4. On second failure, propagates the original exception.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Optional

from robot.api.deco import keyword, library
from selenium.common.exceptions import (
    ElementClickInterceptedException,
    ElementNotInteractableException,
    NoSuchElementException,
    StaleElementReferenceException,
    TimeoutException,
    WebDriverException,
)
from selenium.webdriver.remote.webelement import WebElement

from HealingLibrary.core.constants import (
    CONFIDENCE_AUTO,
    CONFIDENCE_REJECT,
    CONFIDENCE_WARN,
    DEFAULT_METADATA_FILE,
    DEFAULT_RETRY_COUNT,
    DEFAULT_RETRY_DELAY,
)
from HealingLibrary.core.dom_scanner import extract_attributes
from HealingLibrary.core.healer import Healer, HealingError
from HealingLibrary.core.metadata_manager import MetadataManager
from HealingLibrary.utils.utils import (
    js_click,
    locator_to_by_value,
    scroll_into_view,
    wait_for_element_visible,
)

logger = logging.getLogger(__name__)

# Exceptions that indicate a locator failure (trigger heal attempt)
_LOCATOR_FAILURES = (
    NoSuchElementException,
    StaleElementReferenceException,
    TimeoutException,
    WebDriverException,
)


@library(scope="SUITE", version="1.0.0", doc_format="reST")
class HealingLibrary:
    """Robot Framework self-healing locator library.

    Transparently repairs broken Selenium locators at runtime.

    **Initialization parameters**

    ``metadata_path`` (str):
        Path to the JSON file that stores locator fingerprints.
        Defaults to ``locator_metadata.json`` in the current directory.

    ``confidence_reject`` (float):
        Minimum confidence score below which healing is refused (default 40).

    ``confidence_warn`` (float):
        Confidence below which a warning is emitted (default 60).

    ``confidence_auto`` (float):
        Confidence above which healing is applied silently (default 80).

    ``retry_count`` (int):
        Number of interaction retries after healing (default 3).

    ``retry_delay`` (float):
        Seconds between retries (default 0.5).
    """

    ROBOT_LIBRARY_SCOPE = "SUITE"
    ROBOT_LIBRARY_VERSION = "1.0.0"

    def __init__(
        self,
        metadata_path: str = DEFAULT_METADATA_FILE,
        confidence_reject: float = CONFIDENCE_REJECT,
        confidence_warn: float = CONFIDENCE_WARN,
        confidence_auto: float = CONFIDENCE_AUTO,
        retry_count: int = DEFAULT_RETRY_COUNT,
        retry_delay: float = DEFAULT_RETRY_DELAY,
    ) -> None:
        self._meta = MetadataManager(path=metadata_path)
        self._healer = Healer(
            self._meta,
            confidence_reject=confidence_reject,
            confidence_warn=confidence_warn,
            confidence_auto=confidence_auto,
        )
        self._retry_count = retry_count
        self._retry_delay = retry_delay
        logger.info(
            "HealingLibrary initialised — metadata='%s', thresholds=[%.0f/%.0f/%.0f]",
            metadata_path,
            confidence_reject,
            confidence_warn,
            confidence_auto,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @property
    def _driver(self):
        """Retrieve the active Selenium WebDriver from SeleniumLibrary.

        SeleniumLibrary must be imported in the same suite (or globally)
        before HealingLibrary keywords are called.
        """
        from robot.libraries.BuiltIn import BuiltIn

        selenium_lib = BuiltIn().get_library_instance("SeleniumLibrary")
        return selenium_lib.driver

    def _find_element_raw(self, locator: str) -> WebElement:
        """Locate an element using the raw Selenium driver.

        Parameters
        ----------
        locator:
            Robot Framework locator string.

        Returns
        -------
        WebElement

        Raises
        ------
        NoSuchElementException
            When the element cannot be found.
        """
        by, value = locator_to_by_value(locator)
        return self._driver.find_element(by, value)

    def _attempt_heal(self, locator_key: str, original_locator: str) -> Optional[str]:
        """Run the heal cycle and return the new locator, or None on failure.

        Wraps :meth:`Healer.heal` with graceful error logging so that
        callers can decide how to handle a failed healing attempt.
        """
        try:
            healed, score = self._healer.heal(
                self._driver, locator_key, original_locator
            )
            logger.info(
                "HealingLibrary: healed '%s' → '%s' (score=%.1f)",
                locator_key,
                healed,
                score,
            )
            return healed
        except HealingError as exc:
            logger.error("HealingLibrary: healing failed for '%s': %s", locator_key, exc)
            return None

    def _find_with_healing(
        self,
        locator: str,
        locator_key: Optional[str] = None,
    ) -> WebElement:
        """Find an element, healing the locator if the first attempt fails.

        This is the central routine used by all ``Heal *`` keywords.

        Parameters
        ----------
        locator:
            Original Robot Framework locator.
        locator_key:
            Alias for the metadata store.  Defaults to ``locator`` itself.

        Returns
        -------
        WebElement

        Raises
        ------
        NoSuchElementException
            If neither the original nor the healed locator works.
        HealingError
            If healing is attempted but produces no usable candidate.
        """
        key = locator_key or locator

        # --- First attempt with original locator ---
        try:
            element = self._find_element_raw(locator)
            logger.debug(
                "HealingLibrary: '%s' found with original locator on first try", key
            )
            return element
        except _LOCATOR_FAILURES as original_exc:
            logger.warning(
                "HealingLibrary: locator '%s' failed (%s). Triggering heal …",
                locator,
                type(original_exc).__name__,
            )

        # --- Heal cycle ---
        healed_locator = self._attempt_heal(key, locator)
        if healed_locator is None:
            raise NoSuchElementException(
                f"Original locator failed and healing produced no result for '{key}'."
            )

        # --- Retry with healed locator ---
        for attempt in range(1, self._retry_count + 1):
            try:
                element = self._find_element_raw(healed_locator)
                logger.info(
                    "HealingLibrary: element found with healed locator '%s' "
                    "(attempt %d)",
                    healed_locator,
                    attempt,
                )
                return element
            except _LOCATOR_FAILURES as exc:
                logger.warning(
                    "HealingLibrary: healed locator attempt %d/%d failed: %s",
                    attempt,
                    self._retry_count,
                    exc,
                )
                time.sleep(self._retry_delay)

        raise NoSuchElementException(
            f"Healed locator '{healed_locator}' also failed after "
            f"{self._retry_count} retries for key='{key}'."
        )

    # ------------------------------------------------------------------
    # Robot Framework Keywords
    # ------------------------------------------------------------------

    @keyword("Register Locator")
    def register_locator(
        self,
        locator: str,
        locator_key: Optional[str] = None,
    ) -> None:
        """Snapshot the current DOM state of *locator* into metadata.

        Call this keyword **once** when your locators are working so
        that the library has a reference fingerprint for future healing.

        .. code-block:: robotframework

            Register Locator    id=submit-btn    locator_key=checkout_button

        Parameters
        ----------
        locator:
            Robot Framework locator string pointing to an existing element.
        locator_key:
            Human-readable alias for the metadata store.  If omitted,
            *locator* itself is used as the key.
        """
        key = locator_key or locator
        try:
            element = self._find_element_raw(locator)
            attributes = extract_attributes(self._driver, element)
            # Remove the private _element reference before persisting
            attributes.pop("_element", None)
            self._meta.register(key, locator, attributes)
            logger.info(
                "HealingLibrary: registered locator '%s' as key='%s'", locator, key
            )
        except Exception as exc:
            logger.error(
                "HealingLibrary: Register Locator failed for '%s': %s", locator, exc
            )
            raise

    @keyword("Heal Find Element")
    def heal_find_element(
        self,
        locator: str,
        locator_key: Optional[str] = None,
    ) -> WebElement:
        """Locate an element with automatic healing on failure.

        Returns the live ``WebElement`` reference.  Useful when you need
        the element object for custom Selenium operations.

        .. code-block:: robotframework

            ${el}=    Heal Find Element    id=submit-btn    locator_key=submit

        Parameters
        ----------
        locator:
            Original Robot Framework locator.
        locator_key:
            Metadata alias (defaults to *locator*).

        Returns
        -------
        WebElement
        """
        element = self._find_with_healing(locator, locator_key)
        scroll_into_view(self._driver, element)
        wait_for_element_visible(element)
        return element

    @keyword("Heal Click Element")
    def heal_click_element(
        self,
        locator: str,
        locator_key: Optional[str] = None,
        js_fallback: bool = True,
    ) -> None:
        """Click an element with automatic locator healing on failure.

        If the native WebDriver click raises ``ElementClickInterceptedException``
        (e.g. an overlay is partially covering the element), a JavaScript
        ``element.click()`` is attempted as a fallback.

        .. code-block:: robotframework

            Heal Click Element    id=submit-btn    locator_key=submit_button

        Parameters
        ----------
        locator:
            Original Robot Framework locator.
        locator_key:
            Metadata alias (defaults to *locator*).
        js_fallback:
            If ``True`` (default), fall back to JS click on interception.
        """
        element = self._find_with_healing(locator, locator_key)
        scroll_into_view(self._driver, element)
        wait_for_element_visible(element)

        try:
            element.click()
            logger.info("HealingLibrary: clicked '%s'", locator_key or locator)
        except (ElementClickInterceptedException, ElementNotInteractableException) as exc:
            if js_fallback:
                logger.warning(
                    "HealingLibrary: native click intercepted (%s) — using JS fallback",
                    type(exc).__name__,
                )
                js_click(self._driver, element)
            else:
                raise

    @keyword("Heal Input Text")
    def heal_input_text(
        self,
        locator: str,
        text: str,
        locator_key: Optional[str] = None,
        clear_first: bool = True,
    ) -> None:
        """Type *text* into an element with automatic locator healing.

        .. code-block:: robotframework

            Heal Input Text    id=email-field    user@example.com    locator_key=email

        Parameters
        ----------
        locator:
            Original Robot Framework locator.
        text:
            The string to type into the element.
        locator_key:
            Metadata alias (defaults to *locator*).
        clear_first:
            If ``True`` (default), clear the field before typing.
        """
        element = self._find_with_healing(locator, locator_key)
        scroll_into_view(self._driver, element)
        wait_for_element_visible(element)

        if clear_first:
            element.clear()
        element.send_keys(text)
        logger.info(
            "HealingLibrary: typed %d chars into '%s'",
            len(text),
            locator_key or locator,
        )

    @keyword("Heal Get Text")
    def heal_get_text(
        self,
        locator: str,
        locator_key: Optional[str] = None,
    ) -> str:
        """Return the visible text of an element with locator healing.

        .. code-block:: robotframework

            ${msg}=    Heal Get Text    id=status-msg    locator_key=status_message

        Parameters
        ----------
        locator:
            Original Robot Framework locator.
        locator_key:
            Metadata alias (defaults to *locator*).

        Returns
        -------
        str
            The element's ``text`` property (visible text only).
        """
        element = self._find_with_healing(locator, locator_key)
        text = element.text
        logger.info(
            "HealingLibrary: got text '%s' from '%s'",
            text[:60],
            locator_key or locator,
        )
        return text

    @keyword("Heal Get Attribute")
    def heal_get_attribute(
        self,
        locator: str,
        attribute: str,
        locator_key: Optional[str] = None,
    ) -> Optional[str]:
        """Return a DOM attribute value from an element with healing.

        .. code-block:: robotframework

            ${href}=    Heal Get Attribute    id=home-link    href    locator_key=home_link

        Parameters
        ----------
        locator:
            Original Robot Framework locator.
        attribute:
            HTML attribute name (e.g. ``"href"``, ``"value"``).
        locator_key:
            Metadata alias (defaults to *locator*).

        Returns
        -------
        str or None
        """
        element = self._find_with_healing(locator, locator_key)
        value = element.get_attribute(attribute)
        logger.debug(
            "HealingLibrary: attribute '%s'='%s' for '%s'",
            attribute,
            value,
            locator_key or locator,
        )
        return value

    @keyword("Get Healing Statistics")
    def get_healing_statistics(self) -> dict[str, Any]:
        """Return a summary of all healing activity from the metadata store.

        Useful for assertions or reporting at the end of a test run.

        .. code-block:: robotframework

            ${stats}=    Get Healing Statistics
            Log    ${stats}

        Returns
        -------
        dict
            ``{ locator_key: { heal_count, last_healed, healed_locator }, … }``
        """
        entries = self._meta.all_entries()
        stats: dict[str, Any] = {}
        for key, data in entries.items():
            stats[key] = {
                "heal_count":     data.get("heal_count", 0),
                "last_healed":    data.get("last_healed"),
                "healed_locator": data.get("healed_locator"),
            }
        logger.info("HealingLibrary: healing statistics — %s", stats)
        return stats
