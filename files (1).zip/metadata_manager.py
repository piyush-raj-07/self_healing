"""
metadata_manager.py — Persistent Locator Metadata Store
=========================================================

Manages the JSON file that acts as the library's "memory."  Each entry
records the last-known stable attributes of a locator so the scoring
engine can compare them against live DOM candidates.

Schema (one entry)
------------------
::

    "login_button": {
        "original_locator": "id=login-btn",
        "tag":              "button",
        "id":               "login-btn",
        "name":             "",
        "text":             "Log In",
        "class":            "btn btn-primary",
        "aria-label":       "Log in to your account",
        "placeholder":      "",
        "xpath":            "//button[@id='login-btn']",
        "ancestor_path":    "form#login-form > div.actions",
        "healed_locator":   null,
        "heal_count":       0,
        "last_healed":      null
    }

Thread-safety note
------------------
This class is NOT thread-safe.  Robot Framework runs keywords
sequentially by default, so this is acceptable.  Add a threading.Lock
if you ever enable parallelism.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, Optional

from HealingLibrary.core.constants import DEFAULT_METADATA_FILE, METADATA_JSON_INDENT

logger = logging.getLogger(__name__)


class MetadataManager:
    """Load, query, and persist locator metadata from a JSON file.

    Parameters
    ----------
    path:
        File-system path to the JSON metadata store.  Created
        automatically if it does not yet exist.
    """

    def __init__(self, path: str = DEFAULT_METADATA_FILE) -> None:
        self._path = path
        self._store: dict[str, dict[str, Any]] = {}
        self._load()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get(self, locator_key: str) -> Optional[dict[str, Any]]:
        """Return stored metadata for *locator_key*, or ``None`` if absent."""
        return self._store.get(locator_key)

    def all_entries(self) -> dict[str, dict[str, Any]]:
        """Return a shallow copy of the full metadata store."""
        return dict(self._store)

    def register(
        self,
        locator_key: str,
        original_locator: str,
        attributes: dict[str, Any],
    ) -> None:
        """Register or update metadata for a locator.

        Merges *attributes* with any existing record so that partial
        updates (e.g., only refreshing *text*) are non-destructive.

        Parameters
        ----------
        locator_key:
            Human-readable alias, e.g. ``"checkout_button"``.
        original_locator:
            The Robot Framework locator string, e.g. ``"id=checkout"``.
        attributes:
            Dict of attribute name → value extracted from the live element.
        """
        existing = self._store.get(locator_key, {})
        entry: dict[str, Any] = {
            "original_locator": original_locator,
            "tag":              attributes.get("tag", existing.get("tag", "")),
            "id":               attributes.get("id", existing.get("id", "")),
            "name":             attributes.get("name", existing.get("name", "")),
            "text":             attributes.get("text", existing.get("text", "")),
            "class":            attributes.get("class", existing.get("class", "")),
            "aria-label":       attributes.get("aria-label", existing.get("aria-label", "")),
            "placeholder":      attributes.get("placeholder", existing.get("placeholder", "")),
            "xpath":            attributes.get("xpath", existing.get("xpath", "")),
            "ancestor_path":    attributes.get("ancestor_path", existing.get("ancestor_path", "")),
            "healed_locator":   existing.get("healed_locator"),
            "heal_count":       existing.get("heal_count", 0),
            "last_healed":      existing.get("last_healed"),
        }
        self._store[locator_key] = entry
        self._save()
        logger.debug("MetadataManager: registered '%s'", locator_key)

    def record_healing(
        self,
        locator_key: str,
        healed_locator: str,
        new_attributes: dict[str, Any],
    ) -> None:
        """Persist the result of a successful healing operation.

        Updates the stored attributes with *new_attributes* so that
        future scoring uses the freshest known element fingerprint.

        Parameters
        ----------
        locator_key:
            Alias for the locator that was healed.
        healed_locator:
            The new locator string that successfully located the element.
        new_attributes:
            Attribute dict extracted from the healed element.
        """
        entry = self._store.get(locator_key)
        if entry is None:
            logger.warning(
                "MetadataManager: no entry for '%s'; creating from healing.",
                locator_key,
            )
            entry = {}

        entry.update(
            {
                "healed_locator": healed_locator,
                "heal_count": entry.get("heal_count", 0) + 1,
                "last_healed": datetime.now(tz=timezone.utc).isoformat(),
                **{k: v for k, v in new_attributes.items() if v},
            }
        )
        self._store[locator_key] = entry
        self._save()
        logger.info(
            "MetadataManager: recorded healing for '%s' → '%s' (total heals: %d)",
            locator_key,
            healed_locator,
            entry["heal_count"],
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load(self) -> None:
        """Load JSON from disk.  Silently starts with an empty store if
        the file does not exist yet."""
        if not os.path.isfile(self._path):
            logger.info(
                "MetadataManager: '%s' not found; starting with empty store.",
                self._path,
            )
            return
        try:
            with open(self._path, encoding="utf-8") as fh:
                data = json.load(fh)
            if not isinstance(data, dict):
                raise ValueError("Expected a JSON object at top level.")
            self._store = data
            logger.info(
                "MetadataManager: loaded %d entries from '%s'.",
                len(self._store),
                self._path,
            )
        except (json.JSONDecodeError, ValueError) as exc:
            logger.error(
                "MetadataManager: failed to parse '%s': %s — starting fresh.",
                self._path,
                exc,
            )

    def _save(self) -> None:
        """Atomically write the in-memory store back to disk."""
        tmp_path = self._path + ".tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as fh:
                json.dump(self._store, fh, indent=METADATA_JSON_INDENT, ensure_ascii=False)
            os.replace(tmp_path, self._path)
        except OSError as exc:
            logger.error("MetadataManager: could not write '%s': %s", self._path, exc)
