"""
utils.py — Shared Utility Functions and Decorators
====================================================

General-purpose helpers used across the library:

* :func:`retry` — decorator that retries a callable on exception with
  configurable delays.
* :func:`scroll_into_view` — use JavaScript to scroll an element into
  the viewport before interacting with it.
* :func:`js_click` — click an element via JavaScript, bypassing
  WebDriver's native click (useful when an element is obscured).
* :func:`wait_for_element_visible` — busy-wait until an element's
  ``is_displayed()`` returns True.
* :func:`locator_to_by_value` — convert a Robot Framework / Selenium
  locator string to a ``(By, value)`` tuple.
"""

from __future__ import annotations

import functools
import logging
import time
from typing import Any, Callable, Optional, Tuple, TypeVar

from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement

from HealingLibrary.core.constants import DEFAULT_RETRY_COUNT, DEFAULT_RETRY_DELAY

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


# ---------------------------------------------------------------------------
# Retry decorator
# ---------------------------------------------------------------------------

def retry(
    max_attempts: int = DEFAULT_RETRY_COUNT,
    delay: float = DEFAULT_RETRY_DELAY,
    exceptions: tuple[type[Exception], ...] = (Exception,),
) -> Callable[[F], F]:
    """Decorator: retry *func* up to *max_attempts* times on *exceptions*.

    Usage::

        @retry(max_attempts=3, delay=0.5)
        def click_element():
            ...

    Parameters
    ----------
    max_attempts:
        Total number of attempts (including the first one).
    delay:
        Seconds to sleep between attempts.
    exceptions:
        Exception types that trigger a retry.  Others propagate immediately.
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_exc: Optional[Exception] = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as exc:
                    last_exc = exc
                    logger.debug(
                        "retry: attempt %d/%d for '%s' failed: %s",
                        attempt,
                        max_attempts,
                        func.__name__,
                        exc,
                    )
                    if attempt < max_attempts:
                        time.sleep(delay)
            raise last_exc  # type: ignore[misc]
        return wrapper  # type: ignore[return-value]
    return decorator


# ---------------------------------------------------------------------------
# Element interaction helpers
# ---------------------------------------------------------------------------

def scroll_into_view(driver: WebDriver, element: WebElement) -> None:
    """Scroll *element* into the visible viewport using JavaScript.

    Uses ``scrollIntoView({block: 'center'})`` to centre the element
    vertically, reducing the chance that fixed headers or footers occlude it.

    Parameters
    ----------
    driver:
        Active WebDriver instance.
    element:
        Target ``WebElement``.
    """
    try:
        driver.execute_script(
            "arguments[0].scrollIntoView({behavior:'smooth',block:'center'});",
            element,
        )
        time.sleep(0.2)  # Allow smooth-scroll animation to settle
        logger.debug("utils: scrolled element into view")
    except Exception as exc:
        logger.debug("utils: scroll_into_view failed — %s", exc)


def js_click(driver: WebDriver, element: WebElement) -> None:
    """Click *element* via JavaScript (``element.click()``).

    Useful as a fallback when WebDriver's native click raises
    ``ElementClickInterceptedException`` because another element is
    on top of the target.

    Parameters
    ----------
    driver:
        Active WebDriver instance.
    element:
        Target ``WebElement``.
    """
    driver.execute_script("arguments[0].click();", element)
    logger.debug("utils: executed JS click on element")


def wait_for_element_visible(
    element: WebElement,
    timeout: float = 5.0,
    poll: float = 0.2,
) -> bool:
    """Busy-wait until *element* is visible or *timeout* expires.

    Parameters
    ----------
    element:
        A ``WebElement`` that has already been located.
    timeout:
        Maximum seconds to wait.
    poll:
        Polling interval in seconds.

    Returns
    -------
    bool
        ``True`` if the element became visible within *timeout*.
    """
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            if element.is_displayed():
                logger.debug("utils: element is visible")
                return True
        except Exception:
            pass
        time.sleep(poll)
    logger.warning("utils: element did not become visible within %.1f s", timeout)
    return False


# ---------------------------------------------------------------------------
# Locator parsing
# ---------------------------------------------------------------------------

_LOCATOR_STRATEGIES: dict[str, str] = {
    "id":               By.ID,
    "name":             By.NAME,
    "xpath":            By.XPATH,
    "css":              By.CSS_SELECTOR,
    "css_selector":     By.CSS_SELECTOR,
    "class":            By.CLASS_NAME,
    "class_name":       By.CLASS_NAME,
    "tag":              By.TAG_NAME,
    "tag_name":         By.TAG_NAME,
    "link":             By.LINK_TEXT,
    "link_text":        By.LINK_TEXT,
    "partial_link_text": By.PARTIAL_LINK_TEXT,
    "partial_link":     By.PARTIAL_LINK_TEXT,
}


def locator_to_by_value(locator: str) -> Tuple[str, str]:
    """Parse a Robot Framework locator string into a ``(By, value)`` pair.

    Supports the ``strategy=value`` syntax (e.g. ``"id=submit"``).
    Falls back to XPath if no ``=`` separator is found.

    Parameters
    ----------
    locator:
        Robot Framework locator string.

    Returns
    -------
    tuple
        ``(selenium.webdriver.common.by.By constant, value string)``

    Examples
    --------
    >>> locator_to_by_value("id=login-btn")
    ('id', 'login-btn')
    >>> locator_to_by_value("css=button.submit")
    ('css selector', 'button.submit')
    >>> locator_to_by_value("//button[@type='submit']")
    ('xpath', "//button[@type='submit']")
    """
    if "=" in locator:
        strategy, _, value = locator.partition("=")
        by = _LOCATOR_STRATEGIES.get(strategy.lower().strip())
        if by:
            return by, value.strip()

    # Default: treat bare strings starting with // as XPath
    if locator.startswith("//") or locator.startswith("(//"):
        return By.XPATH, locator

    # Final fallback: CSS selector
    return By.CSS_SELECTOR, locator
