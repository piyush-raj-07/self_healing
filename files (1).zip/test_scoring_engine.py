"""
test_scoring_engine.py — Unit Tests for the Scoring Engine
===========================================================

Run with:  pytest tests/ -v
"""

from __future__ import annotations

import sys
import os

# Allow running tests without installing the package
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from HealingLibrary.core.scoring_engine import (
    _fuzzy_ratio,
    _is_dynamic_id,
    _token_set_ratio,
    rank_candidates,
    score_candidate,
)


# ---------------------------------------------------------------------------
# _fuzzy_ratio
# ---------------------------------------------------------------------------

class TestFuzzyRatio:
    def test_identical_strings(self):
        assert _fuzzy_ratio("login", "login") == pytest.approx(1.0)

    def test_completely_different(self):
        assert _fuzzy_ratio("submit", "xyz") < 0.5

    def test_empty_string_returns_zero(self):
        assert _fuzzy_ratio("", "login") == 0.0
        assert _fuzzy_ratio("login", "") == 0.0

    def test_case_insensitive(self):
        assert _fuzzy_ratio("Login", "login") == pytest.approx(1.0)

    def test_partial_similarity(self):
        ratio = _fuzzy_ratio("login-button", "login_button")
        assert 0.8 < ratio < 1.0


# ---------------------------------------------------------------------------
# _token_set_ratio
# ---------------------------------------------------------------------------

class TestTokenSetRatio:
    def test_same_classes_different_order(self):
        score = _token_set_ratio("btn primary large", "large btn primary")
        assert score == pytest.approx(1.0)

    def test_subset_classes(self):
        score = _token_set_ratio("btn primary", "btn primary large")
        assert 0.6 < score < 1.0

    def test_empty_returns_zero(self):
        assert _token_set_ratio("", "btn") == 0.0


# ---------------------------------------------------------------------------
# _is_dynamic_id
# ---------------------------------------------------------------------------

class TestIsDynamicId:
    @pytest.mark.parametrize("dynamic_id", [
        "ember1234",
        "react99",
        "a123456",
        "123456789",
        "550e8400-e29b-41d4-a716-446655440000",
    ])
    def test_dynamic_ids_detected(self, dynamic_id):
        assert _is_dynamic_id(dynamic_id) is True

    @pytest.mark.parametrize("stable_id", [
        "login-btn",
        "submit",
        "email-field",
        "checkout_button",
    ])
    def test_stable_ids_not_flagged(self, stable_id):
        assert _is_dynamic_id(stable_id) is False

    def test_empty_id_is_not_dynamic(self):
        assert _is_dynamic_id("") is False


# ---------------------------------------------------------------------------
# score_candidate
# ---------------------------------------------------------------------------

class TestScoreCandidate:
    def _make_ref(self) -> dict:
        return {
            "id":          "login-btn",
            "name":        "",
            "text":        "Log In",
            "class":       "btn btn-primary",
            "aria-label":  "Log in",
            "placeholder": "",
            "tag":         "button",
            "xpath":       "//button[@id='login-btn']",
            "ancestor_path": "form#login > div.actions",
        }

    def test_perfect_match_scores_high(self):
        ref = self._make_ref()
        cand = dict(ref)  # identical
        score = score_candidate(ref, cand)
        # Attributes with matching non-empty values contribute their full weight.
        # Attributes where BOTH sides are empty contribute 0 (neutral, not a bonus).
        # The reference has 'name'='' and 'placeholder'='' → those weights go unused.
        # So the maximum achievable score is 100 - 15(name) - 10(placeholder) = 75.
        assert score >= 70.0

    def test_empty_candidate_scores_low(self):
        ref = self._make_ref()
        cand: dict = {}
        score = score_candidate(ref, cand)
        assert score < 20.0

    def test_partial_match_scores_mid_range(self):
        ref = self._make_ref()
        cand = {
            "id":          "",
            "name":        "",
            "text":        "Log In",      # matches
            "class":       "btn-primary", # partial
            "aria-label":  "",
            "placeholder": "",
            "tag":         "button",      # matches
            "xpath":       "",
            "ancestor_path": "",
        }
        score = score_candidate(ref, cand)
        # text(15) + partial class(~4) + tag(8) contribute; others are 0
        assert 20.0 < score < 60.0

    def test_dynamic_id_penalty_applied(self):
        ref = self._make_ref()
        cand_stable = dict(ref)
        cand_dynamic = dict(ref)
        cand_dynamic["id"] = "react9999"  # dynamic ID

        score_stable  = score_candidate(ref, cand_stable)
        score_dynamic = score_candidate(ref, cand_dynamic)
        assert score_stable > score_dynamic


# ---------------------------------------------------------------------------
# rank_candidates
# ---------------------------------------------------------------------------

class TestRankCandidates:
    def test_best_candidate_ranked_first(self):
        ref = {
            "id": "submit", "name": "", "text": "Submit",
            "class": "btn", "aria-label": "", "placeholder": "",
            "tag": "button", "xpath": "", "ancestor_path": "",
        }
        best = {**ref}
        worse = {
            "id": "", "name": "", "text": "Cancel",
            "class": "btn-danger", "aria-label": "", "placeholder": "",
            "tag": "button", "xpath": "", "ancestor_path": "",
        }
        ranked = rank_candidates(ref, [worse, best])
        assert ranked[0][0] > ranked[1][0]
        assert ranked[0][1] is best

    def test_returns_empty_list_for_no_candidates(self):
        ref = {"id": "x", "tag": "button"}
        assert rank_candidates(ref, []) == []
