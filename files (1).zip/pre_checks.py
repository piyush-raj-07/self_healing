"""
pre_checks.py — Pre-Healing Environment Validation
====================================================

Before attempting to heal a broken locator we must ensure the page
environment is stable enough for DOM scanning to be meaningful.
These checks run in sequence; each one either resolves a blocking
condition or raises an informative exception.

Checks performed
----------------
1. **Page load state** — waits for ``document.readyState == 'complete'``.
2. **Loading overlays** — waits for CSS spinner/overlay elements to vanish.
3. **Blocking modals / popups** — detects unexpected dialogs and attempts
   to dismiss them.
4. **Iframe context** — ensures the driver is at the default content
   level so scans cover the full document.
"""

from __future__ import annotations

import logging
import time
from typing import Optional

from selenium.common.exceptions import NoAlertPresentException, NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from HealingLibrary.core.constants import (
    MODAL_SELECTORS,
    OVERLAY_SELECTORS,
    PAGE_LOAD_TIMEOUT,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------

def wait_for_page_load(driver: WebDriver, timeout: float = PAGE_LOAD_TIMEOUT) -> bool:
    """Block until ``document.readyState`` equals ``'complete'``.

    Parameters
    ----------
    driver:
        Active WebDriver instance.
    timeout:
        Maximum seconds to wait.

    Returns
    -------
    bool
        ``True`` if the page became ready within *timeout*, ``False`` otherwise.
    """
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            state = driver.execute_script("return document.readyState;")
            if state == "complete":
                logger.debug("pre_checks: page load state is 'complete'")
                return True
        except Exception as exc:
            logger.debug("pre_checks: error checking readyState — %s", exc)
        time.sleep(0.3)
    logger.warning(
        "pre_checks: page did not reach 'complete' state within %.1f s", timeout
    )
    return False


def wait_for_overlays_to_clear(
    driver: WebDriver,
    timeout: float = PAGE_LOAD_TIMEOUT,
) -> bool:
    """Wait until all known loading overlays disappear from the DOM.

    Iterates over ``OVERLAY_SELECTORS``.  An overlay is considered gone
    when it either doesn't exist or is not displayed.

    Returns
    -------
    bool
        ``True`` if all overlays cleared, ``False`` on timeout.
    """
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        visible_overlays = []
        for selector in OVERLAY_SELECTORS:
            try:
                elements = driver.find_elements(By.CSS_SELECTOR, selector)
                visible = [el for el in elements if el.is_displayed()]
                if visible:
                    visible_overlays.append(selector)
            except Exception:
                pass
        if not visible_overlays:
            logger.debug("pre_checks: no blocking overlays detected")
            return True
        logger.debug(
            "pre_checks: overlays still visible: %s — waiting …", visible_overlays
        )
        time.sleep(0.4)
    logger.warning("pre_checks: overlays did not clear within %.1f s", timeout)
    return False


def dismiss_alert_if_present(driver: WebDriver) -> bool:
    """Accept any native browser alert that might be blocking interaction.

    Returns
    -------
    bool
        ``True`` if an alert was found and dismissed.
    """
    try:
        alert = driver.switch_to.alert
        text = alert.text
        alert.accept()
        logger.info("pre_checks: dismissed browser alert — '%s'", text[:80])
        return True
    except NoAlertPresentException:
        return False
    except Exception as exc:
        logger.debug("pre_checks: error dismissing alert — %s", exc)
        return False


def detect_blocking_modal(driver: WebDriver) -> Optional[str]:
    """Detect whether a CSS modal / dialog is blocking the page.

    Returns the selector of the first visible modal, or ``None`` if the
    page is unobstructed.
    """
    for selector in MODAL_SELECTORS:
        try:
            elements = driver.find_elements(By.CSS_SELECTOR, selector)
            visible = [el for el in elements if el.is_displayed()]
            if visible:
                logger.warning(
                    "pre_checks: blocking modal detected via '%s'", selector
                )
                return selector
        except Exception:
            pass
    return None


def ensure_default_content(driver: WebDriver) -> None:
    """Switch the driver back to the top-level document.

    This is a safety reset — if a previous keyword left the driver
    focused inside an iframe, DOM scanning would be scoped to that
    frame only.
    """
    try:
        driver.switch_to.default_content()
        logger.debug("pre_checks: switched to default content")
    except Exception as exc:
        logger.debug("pre_checks: could not switch to default content — %s", exc)


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------

def run_all_pre_checks(
    driver: WebDriver,
    timeout: float = PAGE_LOAD_TIMEOUT,
) -> dict[str, object]:
    """Run the full pre-healing check suite and return a status summary.

    Parameters
    ----------
    driver:
        Active WebDriver instance.
    timeout:
        Per-check timeout in seconds.

    Returns
    -------
    dict with keys:
        * ``page_ready``   (bool) — page load state reached 'complete'
        * ``overlays_clear`` (bool) — no loading overlay visible
        * ``alert_dismissed`` (bool) — a native alert was found and dismissed
        * ``modal_selector``  (str | None) — CSS selector of a blocking modal
        * ``context_reset``   (bool) — driver was reset to default content
    """
    ensure_default_content(driver)
    page_ready = wait_for_page_load(driver, timeout)
    overlays_clear = wait_for_overlays_to_clear(driver, timeout)
    alert_dismissed = dismiss_alert_if_present(driver)
    modal_selector = detect_blocking_modal(driver)

    status = {
        "page_ready":       page_ready,
        "overlays_clear":   overlays_clear,
        "alert_dismissed":  alert_dismissed,
        "modal_selector":   modal_selector,
        "context_reset":    True,
    }
    logger.info("pre_checks summary: %s", status)
    return status
