# Self-Healing Library for Robot Framework

A production-ready self-healing Robot Framework library for Selenium-based UI tests. When a locator breaks (due to an application update, refactor, or dynamic ID change) the library automatically finds the correct element using fuzzy matching, semantic similarity, and multi-strategy DOM scanning — and heals itself for future runs.

---

## Table of Contents

1. [How It Works](#how-it-works)
2. [Architecture](#architecture)
3. [Installation](#installation)
4. [Quick Start](#quick-start)
5. [Library Parameters](#library-parameters)
6. [Keywords Reference](#keywords-reference)
7. [Confidence Scoring](#confidence-scoring)
8. [Metadata JSON Schema](#metadata-json-schema)
9. [Integration Guide](#integration-guide)
10. [Troubleshooting](#troubleshooting)

---

## How It Works

```
Test runs Heal Click Element with locator "id=login-btn"
         │
         ▼
Step 1 ─ Try original locator  ─────────────────────► SUCCESS → done
         │ FAILS
         ▼
Step 2 ─ Pre-healing checks
         • Wait for page readyState = 'complete'
         • Wait for loaders / spinners to vanish
         • Detect blocking popups / modals
         │
         ▼
Step 3 ─ Load stored metadata from locator_metadata.json
         (tag, text, classes, aria-label, embedding vector…)
         │
         ▼
Step 4 ─ Scan live DOM with multiple strategies
         • Tag-based search       • Text content search
         • Attribute sweep        • Class overlap search
         • Shadow DOM traversal   • iframe scanning
         │
         ▼
Step 5 ─ Score all candidates
         Weighted traditional score (id, name, text, classes…)
         + Semantic embedding similarity (all-MiniLM-L6-v2)
         = Final confidence score per candidate
         │
         ▼
Step 6 ─ Validate best match
         confidence >= threshold?  NO → raise original error
         │ YES
         ▼
Step 7 ─ Execute action on healed element
         Normal click → JS fallback if intercepted
         │
         ▼
Step 8 ─ Persist healed locator in metadata JSON
         (used as fast-path on next run)
```

---

## Architecture

```
self_healing_library/
├── __init__.py                  Package entry point
├── SelfHealingLibrary.py        Robot Framework library wrapper (keywords)
├── healing_engine.py            Orchestrates the full healing flow
├── metadata_manager.py          Reads/writes locator_metadata.json
├── dom_scanner.py               Scans live DOM, handles iframes + shadow DOM
├── similarity_engine.py         Fuzzy matching (rapidfuzz / difflib)
├── embedding_matcher.py         Semantic similarity (sentence-transformers)
├── scorer.py                    Combines signals into a final confidence score
└── page_state_checker.py        Page-ready, loader, popup, visibility checks
```

---

## Installation

### Option A – Add to an Existing Project (Recommended)

```bash
# 1. Copy the self_healing_library/ folder into your project root
cp -r self_healing_library/ /path/to/your-rf-project/

# 2. Install core dependencies
pip install robotframework>=5.0 \
            robotframework-seleniumlibrary>=6.0 \
            selenium>=4.0 \
            rapidfuzz>=3.0

# 3. (Optional) Enable semantic matching
pip install sentence-transformers torch
```

### Option B – Install as a Package

```bash
# From the repository root
pip install -e .

# Or with semantic extras
pip install -e ".[semantic]"
```

### Option C – Install From requirements.txt

```bash
pip install -r requirements.txt
# Then uncomment sentence-transformers lines for semantic matching
```

---

## Quick Start

### 1. Add the library to your test suite

```robot
*** Settings ***
Library    SeleniumLibrary
Library    self_healing_library.SelfHealingLibrary
...        metadata_path=${CURDIR}/locator_metadata.json
...        confidence_threshold=0.60
```

### 2. Register locators early (build the baseline)

```robot
*** Test Cases ***
Setup - Register Locators
    Open Browser    https://myapp.com/login    Chrome
    Register Locator    id=login-btn    login_button
    Register Locator    id=username     username_field
    Register Locator    id=password     password_field
```

### 3. Use healing keywords in your tests

```robot
Login Test
    Heal Input Text       id=username    testuser@example.com    locator_key=username_field
    Heal Input Text       id=password    secret123               locator_key=password_field
    Heal Click Element    id=login-btn                          locator_key=login_button
    Page Should Contain   Dashboard
```

---

## Library Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `metadata_path` | str | `locator_metadata.json` | Path to metadata persistence file |
| `confidence_threshold` | float | `0.60` | Minimum score to accept a healed locator |
| `auto_store_threshold` | float | `0.75` | Minimum score to persist the healed locator |
| `enable_js_fallback` | bool | `True` | Use JS click when normal click is intercepted |
| `scan_iframes` | bool | `True` | Search inside `<iframe>` elements |
| `scan_shadow_dom` | bool | `True` | Pierce shadow DOM roots |
| `page_ready_timeout` | float | `10.0` | Seconds to wait for page-ready checks |
| `max_candidates` | int | `50` | Max DOM candidates per healing attempt |
| `semantic_blend` | float | `0.20` | Weight of embedding similarity in final score |

---

## Keywords Reference

### `Register Locator`
```robot
Register Locator    locator    locator_key
```
Snapshot the element and persist its metadata. Call in test setup before page changes.

| Argument | Description |
|----------|-------------|
| `locator` | SeleniumLibrary locator string (e.g. `id=login-btn`) |
| `locator_key` | Logical name stored in metadata JSON |

---

### `Heal Click Element`
```robot
${used_locator}=    Heal Click Element    locator    [locator_key]    [timeout]
```
Click element; heals automatically if original locator fails.

---

### `Heal Input Text`
```robot
${used_locator}=    Heal Input Text    locator    text    [locator_key]    [timeout]
```
Type text into a field; heals automatically if original locator fails.

---

### `Heal Get Text`
```robot
${text}=    Heal Get Text    locator    [locator_key]    [timeout]
```
Get visible text (or `value` attribute) from element; heals if needed.

---

### `Get Healing Stats`
```robot
${stats}=    Get Healing Stats    [locator_key]
Log    Heal count: ${stats}[heal_count]
```
Returns a dict with `heal_count`, `healed_locator`, `average_confidence`, `last_healed`.

---

## Confidence Scoring

### Attribute Weights

| Signal | Default Weight | Notes |
|--------|---------------|-------|
| `id` | 0.20 | Reduced 70% if ID looks auto-generated |
| `text` | 0.20 | Visible text content |
| `name` | 0.15 | HTML `name` attribute |
| `aria_label` | 0.12 | Accessibility label |
| `placeholder` | 0.08 | Input placeholder |
| `classes` | 0.08 | Jaccard similarity, dynamic classes filtered |
| `tag` | 0.07 | HTML tag name |
| `data_testid` | 0.05 | `data-testid` attribute |
| `ancestor_path` | 0.05 | XPath structural similarity |

### Final Score Formula

```
final_score = (1 - semantic_blend) × traditional_weighted_score
            + semantic_blend × cosine_similarity(embedding_a, embedding_b)
```

With `semantic_blend=0.20` (default): 80% traditional + 20% semantic.

### Threshold Meanings

| Threshold | Action |
|-----------|--------|
| `>= auto_store_threshold (0.75)` | Use healed locator + persist for future runs |
| `>= confidence_threshold (0.60)` | Use healed locator but don't persist |
| `< confidence_threshold` | Reject; raise original exception |

---

## Metadata JSON Schema

```json
{
  "login_button": {
    "original_locator": "id=login-btn",
    "healed_locator":   "xpath=//button[contains(text(),'Sign In')]",
    "tag":              "button",
    "text":             "Sign In",
    "id":               "login-btn",
    "name":             "",
    "classes":          ["btn", "btn-primary"],
    "aria_label":       "Login to your account",
    "placeholder":      "",
    "attributes":       { "data-testid": "login-button" },
    "xpath_path":       "//html/body/div/form/button",
    "embedding":        [],
    "confidence_history": [0.91, 0.88, 0.94],
    "last_healed":      "2024-01-15T10:30:00",
    "heal_count":       3
  }
}
```

---

## Integration Guide

### Adding to an Existing Project

1. **Copy the library** into your project root or a `libs/` subdirectory
2. **Add to PYTHONPATH** if installed in a non-standard location:
   ```bash
   export PYTHONPATH="${PYTHONPATH}:/path/to/your-project/libs"
   ```
3. **Import in your resource files** or directly in test suites
4. **Run with robot**:
   ```bash
   robot --outputdir results/ tests/
   ```

### CI/CD Integration

```yaml
# GitHub Actions example
- name: Run Robot Framework Tests
  run: |
    pip install -r requirements.txt
    robot --outputdir results/ --variable BROWSER:Chrome tests/
  env:
    PYTHONPATH: ${{ github.workspace }}
```

### Storing metadata across CI runs

Check `locator_metadata.json` into version control. After each healing event the file updates; commit it to preserve healing improvements.

---

## Troubleshooting

### "No metadata for key – consider calling Register Locator first"
Run your suite once with all `Register Locator` calls (or a dedicated setup test) to build the baseline metadata before tests run in a changed environment.

### Confidence is always 0 / healing never succeeds
- Check that `SeleniumLibrary` is imported and a browser is open
- Lower `confidence_threshold` temporarily to `0.40` and check logs
- Make sure the element actually exists on the current page

### Semantic matching not working
Install the optional dependencies:
```bash
pip install sentence-transformers torch
```
The first run downloads ~22 MB model weights. Subsequent runs use the cache.

### Dynamic IDs causing false matches
Elements with IDs matching patterns like `_abc123`, long hex strings, or 3+ consecutive digits are automatically penalised (weight multiplied by 0.30). If a legitimate ID is being penalised, update `_DYNAMIC_ID_RE` in `dom_scanner.py`.

### Healing is slow
- Reduce `max_candidates` (default 50)
- Set `scan_shadow_dom=False` if your app doesn't use shadow DOM
- Set `scan_iframes=False` if your app doesn't use iframes
- Pre-register locators so the cached healed locator fast-path is used
