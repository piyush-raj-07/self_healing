"""
tests/test_healing_library.py
------------------------------
Unit tests for the self-healing library components.

Run with:
    pytest tests/ -v

These tests use unittest.mock to avoid requiring a live browser.
"""

import json
import os
import tempfile
import unittest
from unittest.mock import MagicMock, patch, PropertyMock

# ---------------------------------------------------------------------------
# MetadataManager tests
# ---------------------------------------------------------------------------
from self_healing_library.metadata_manager import MetadataManager


class TestMetadataManager(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(
            suffix=".json", delete=False, mode="w"
        )
        self.tmp.write("{}")
        self.tmp.close()
        self.mm = MetadataManager(self.tmp.name)

    def tearDown(self):
        os.unlink(self.tmp.name)

    def test_store_and_retrieve_metadata(self):
        self.mm.store_locator_metadata(
            "btn",
            "id=login-btn",
            {"tag": "button", "text": "Login"},
        )
        meta = self.mm.get_locator_metadata("btn")
        self.assertIsNotNone(meta)
        self.assertEqual(meta["tag"], "button")
        self.assertEqual(meta["original_locator"], "id=login-btn")

    def test_store_healed_locator(self):
        self.mm.store_healed_locator("btn", "xpath=//button[text()='Sign In']", 0.85)
        healed = self.mm.get_healed_locator("btn")
        self.assertEqual(healed, "xpath=//button[text()='Sign In']")

    def test_confidence_history_rolling(self):
        for i in range(25):
            self.mm.store_healed_locator("btn", "xpath=//button", float(i) / 25)
        meta = self.mm.get_locator_metadata("btn")
        # Should cap at MAX_HISTORY_LENGTH (20)
        self.assertLessEqual(len(meta["confidence_history"]), 20)

    def test_average_confidence(self):
        self.mm.store_healed_locator("btn", "xpath=//button", 0.80)
        self.mm.store_healed_locator("btn", "xpath=//button", 0.90)
        avg = self.mm.get_average_confidence("btn")
        self.assertAlmostEqual(avg, 0.85, places=2)

    def test_persistence(self):
        self.mm.store_locator_metadata("key1", "id=x", {"tag": "div"})
        # Re-load from disk
        mm2 = MetadataManager(self.tmp.name)
        self.assertIsNotNone(mm2.get_locator_metadata("key1"))

    def test_missing_key_returns_none(self):
        self.assertIsNone(self.mm.get_locator_metadata("nonexistent"))
        self.assertIsNone(self.mm.get_healed_locator("nonexistent"))


# ---------------------------------------------------------------------------
# SimilarityEngine tests
# ---------------------------------------------------------------------------
from self_healing_library.similarity_engine import (
    text_similarity,
    class_overlap_score,
    ancestor_path_score,
    attribute_similarity,
)


class TestSimilarityEngine(unittest.TestCase):
    def test_identical_strings(self):
        self.assertEqual(text_similarity("Login", "Login"), 1.0)

    def test_empty_strings_both(self):
        self.assertEqual(text_similarity("", ""), 1.0)

    def test_one_empty(self):
        self.assertEqual(text_similarity("Login", ""), 0.0)

    def test_partial_match(self):
        score = text_similarity("Login", "Login Now")
        self.assertGreater(score, 0.5)

    def test_token_reorder(self):
        # "Sign In" vs "In Sign" should score high with token sort
        score = text_similarity("Sign In", "In Sign")
        self.assertGreater(score, 0.7)

    def test_class_overlap_identical(self):
        self.assertEqual(class_overlap_score(["btn", "primary"], ["btn", "primary"]), 1.0)

    def test_class_overlap_partial(self):
        score = class_overlap_score(["btn", "primary", "large"], ["btn", "primary"])
        self.assertAlmostEqual(score, 2 / 3, places=2)

    def test_class_overlap_dynamic_filtered(self):
        # Dynamic class names like "abc123" should be ignored
        score = class_overlap_score(["btn", "abc123"], ["btn", "xyz456"])
        # Only "btn" vs "btn" after filtering → 1.0
        self.assertEqual(score, 1.0)

    def test_ancestor_path_identical(self):
        xpath = "//div[@id='main']/form/button"
        self.assertAlmostEqual(ancestor_path_score(xpath, xpath), 1.0, places=1)

    def test_ancestor_path_partial(self):
        a = "//div[@id='main']/form/button"
        b = "//div[@id='main']/form/input"
        score = ancestor_path_score(a, b)
        # Should share 2 of 4 unique tokens (div, form shared; button, input differ)
        # Jaccard = 2/4 = 0.5 exactly → assert >= 0.5
        self.assertGreaterEqual(score, 0.5)

    def test_ancestor_path_empty(self):
        self.assertEqual(ancestor_path_score("", "//div/button"), 0.0)

    def test_attribute_similarity_same_tag(self):
        stored = {"tag": "button", "text": "Login", "id": "", "name": "",
                  "classes": [], "aria_label": "", "placeholder": "", "attributes": {}}
        cand   = {"tag": "button", "text": "Login", "id": "", "name": "",
                  "classes": [], "aria_label": "", "placeholder": "", "attributes": {}}
        scores = attribute_similarity(stored, cand)
        self.assertEqual(scores["tag"], 1.0)
        self.assertEqual(scores["text"], 1.0)

    def test_attribute_similarity_different_tag(self):
        stored = {"tag": "button", "text": "", "id": "", "name": "",
                  "classes": [], "aria_label": "", "placeholder": "", "attributes": {}}
        cand   = {"tag": "input", "text": "", "id": "", "name": "",
                  "classes": [], "aria_label": "", "placeholder": "", "attributes": {}}
        scores = attribute_similarity(stored, cand)
        self.assertEqual(scores["tag"], 0.0)


# ---------------------------------------------------------------------------
# Scorer tests (mocked embeddings)
# ---------------------------------------------------------------------------
from self_healing_library.scorer import Scorer


class TestScorer(unittest.TestCase):
    def _make_meta(self, **kwargs):
        base = {
            "tag": "button", "text": "Login", "id": "login-btn",
            "name": "", "classes": ["btn"], "aria_label": "",
            "placeholder": "", "attributes": {}, "xpath_path": "",
            "embedding": [],
        }
        base.update(kwargs)
        return base

    def _make_candidate(self, **kwargs):
        base = {
            "element": MagicMock(),
            "tag": "button", "text": "Login", "id": "login-btn",
            "name": "", "classes": ["btn"], "aria_label": "",
            "placeholder": "", "attributes": {}, "xpath": "",
            "in_iframe": False, "iframe_index": None, "in_shadow": False,
        }
        base.update(kwargs)
        return base

    @patch("self_healing_library.scorer.embeddings_available", return_value=False)
    def test_perfect_match(self, _):
        scorer = Scorer(min_confidence=0.0)
        stored = self._make_meta()
        cand   = self._make_candidate()
        conf, best = scorer.best_match(stored, [cand])
        self.assertIsNotNone(best)
        self.assertGreater(conf, 0.8)

    @patch("self_healing_library.scorer.embeddings_available", return_value=False)
    def test_no_match_below_threshold(self, _):
        scorer = Scorer(min_confidence=0.95)
        stored = self._make_meta(text="Login")
        cand   = self._make_candidate(text="Completely different text XYZ",
                                       id="xyz999", classes=["unrelated"])
        conf, best = scorer.best_match(stored, [cand])
        self.assertIsNone(best)

    @patch("self_healing_library.scorer.embeddings_available", return_value=False)
    def test_text_change_login_to_sign_in(self, _):
        """Even fuzzy matching should give a decent score for Login→Sign In."""
        scorer = Scorer(min_confidence=0.0)
        stored = self._make_meta(text="Login")
        cand   = self._make_candidate(text="Sign In", id="")
        conf, best = scorer.best_match(stored, [cand])
        # Text differs, but tag/class still match → some score
        self.assertIsNotNone(best)
        self.assertGreater(conf, 0.20)

    @patch("self_healing_library.scorer.embeddings_available", return_value=False)
    def test_dynamic_id_penalised(self, _):
        scorer = Scorer(min_confidence=0.0)
        stored = self._make_meta(id="stable-id")
        # Dynamic ID – should reduce the id contribution
        cand_dynamic = self._make_candidate(id="abc1234def5678")
        cand_stable  = self._make_candidate(id="stable-id")
        conf_d, _ = scorer.best_match(stored, [cand_dynamic])
        conf_s, _ = scorer.best_match(stored, [cand_stable])
        self.assertGreater(conf_s, conf_d)

    @patch("self_healing_library.scorer.embeddings_available", return_value=False)
    def test_explain_returns_breakdown(self, _):
        scorer = Scorer()
        stored = self._make_meta()
        cand   = self._make_candidate()
        info = scorer.explain(stored, cand)
        self.assertIn("confidence", info)
        self.assertIn("attr_scores", info)
        self.assertIn("semantic", info)


# ---------------------------------------------------------------------------
# DOMScanner helpers
# ---------------------------------------------------------------------------
from self_healing_library.dom_scanner import is_dynamic_identifier


class TestDynamicIdentifier(unittest.TestCase):
    def test_static_ids(self):
        self.assertFalse(is_dynamic_identifier("login-btn"))
        self.assertFalse(is_dynamic_identifier("submit"))
        self.assertFalse(is_dynamic_identifier("btn-primary"))

    def test_dynamic_ids(self):
        self.assertTrue(is_dynamic_identifier("abc12345"))   # 5+ digits
        self.assertTrue(is_dynamic_identifier("a1b2c3d4"))   # long hex-like
        self.assertTrue(is_dynamic_identifier("_comp93"))    # _abc12 pattern

    def test_mixed(self):
        self.assertFalse(is_dynamic_identifier("user-name-12"))   # 2 digits, ok
        self.assertTrue(is_dynamic_identifier("user-1234567"))    # 7 digits


# ---------------------------------------------------------------------------
# HealingEngine._parse_locator tests (no browser needed)
# ---------------------------------------------------------------------------
from self_healing_library.healing_engine import HealingEngine
from selenium.webdriver.common.by import By


class TestLocatorParsing(unittest.TestCase):
    def test_id_prefix(self):
        by, val = HealingEngine._parse_locator("id=login-btn")
        self.assertEqual(by, By.ID)
        self.assertEqual(val, "login-btn")

    def test_xpath_prefix(self):
        by, val = HealingEngine._parse_locator("xpath=//button[@text='Login']")
        self.assertEqual(by, By.XPATH)
        self.assertEqual(val, "//button[@text='Login']")

    def test_css_prefix(self):
        by, val = HealingEngine._parse_locator("css=.btn-primary")
        self.assertEqual(by, By.CSS_SELECTOR)
        self.assertEqual(val, ".btn-primary")

    def test_bare_xpath(self):
        by, val = HealingEngine._parse_locator("//button")
        self.assertEqual(by, By.XPATH)
        self.assertEqual(val, "//button")

    def test_no_prefix_treated_as_id(self):
        by, val = HealingEngine._parse_locator("login-btn")
        self.assertEqual(by, By.ID)
        self.assertEqual(val, "login-btn")

    def test_derive_key(self):
        key = HealingEngine._derive_key("id=login-btn")
        # "login-btn" → "login_btn" (hyphens replaced, no trailing underscore)
        self.assertIn("login", key)
        self.assertIn("btn", key)
        self.assertLessEqual(len(key), 60)

    def test_derive_key_xpath(self):
        key = HealingEngine._derive_key("xpath=//button[@type='submit']")
        # Should be sanitised and truncated
        self.assertLessEqual(len(key), 60)
        self.assertNotIn("/", key)


# ---------------------------------------------------------------------------
# EmbeddingMatcher (without requiring torch)
# ---------------------------------------------------------------------------
from self_healing_library.embedding_matcher import cosine_similarity


class TestCosimSimilarity(unittest.TestCase):
    def test_identical_vectors(self):
        v = [0.5, 0.5, 0.5, 0.5]
        self.assertAlmostEqual(cosine_similarity(v, v), 1.0, places=3)

    def test_orthogonal_vectors(self):
        a = [1.0, 0.0]
        b = [0.0, 1.0]
        self.assertAlmostEqual(cosine_similarity(a, b), 0.0, places=3)

    def test_empty_vectors(self):
        self.assertEqual(cosine_similarity([], []), 0.0)

    def test_mismatched_lengths(self):
        self.assertEqual(cosine_similarity([1, 2], [1, 2, 3]), 0.0)


if __name__ == "__main__":
    unittest.main()
