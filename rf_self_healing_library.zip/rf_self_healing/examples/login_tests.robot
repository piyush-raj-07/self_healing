*** Settings ***
Documentation     Example test suite demonstrating the SelfHealingLibrary.
...
...               This suite tests a login flow using self-healing locators.
...               If the application changes element IDs or attributes, the
...               library will automatically find the correct elements using
...               fuzzy matching, semantic similarity, and DOM scanning.
...
...               Prerequisites:
...               - pip install robotframework selenium robotframework-seleniumlibrary
...               - pip install self-healing-library   (or add to PYTHONPATH)
...               - A WebDriver binary matching your browser (e.g. chromedriver)

Library           SeleniumLibrary
Library           self_healing_library.SelfHealingLibrary
...               metadata_path=${CURDIR}/locator_metadata.json
...               confidence_threshold=0.60
...               auto_store_threshold=0.75
...               enable_js_fallback=${True}
...               scan_iframes=${True}
...               scan_shadow_dom=${True}
...               page_ready_timeout=15

Resource          ${CURDIR}/resources/common.resource

Suite Setup       Open Browser And Navigate
Suite Teardown    Close All Browsers

*** Variables ***
${BROWSER}        Chrome
${BASE_URL}       https://example-app.com
${TIMEOUT}        15s

# --- Original locators as written by the automation developer ---
# These may break when the app is refactored; the library heals them.
${LOC_USERNAME}       id=username
${LOC_PASSWORD}       id=password
${LOC_LOGIN_BTN}      id=login-btn
${LOC_SUBMIT}         xpath=//button[@type='submit']
${LOC_PAGE_HEADING}   css=h1.page-title
${LOC_SEARCH}         name=q
${LOC_LOGOUT}         xpath=//a[text()='Logout']
${LOC_NAV_PROFILE}    css=nav .user-menu .profile-link
${LOC_ERROR_MSG}      css=.alert-danger

*** Test Cases ***

TC01 - Register All Locators Before Test Run
    [Documentation]    Snapshot all locators on a known-good page state.
    ...                Run this test FIRST so the library has baseline data.
    [Tags]             setup    registration
    Navigate To Login Page
    # Register each locator with a stable logical key
    Register Locator    ${LOC_USERNAME}       username_field
    Register Locator    ${LOC_PASSWORD}       password_field
    Register Locator    ${LOC_LOGIN_BTN}      login_button
    Register Locator    ${LOC_SUBMIT}         submit_button
    Log    All locators registered successfully.

TC02 - Successful Login With Self-Healing
    [Documentation]    Login using self-healing keywords.
    ...
    ...                If the app has been updated and element IDs changed,
    ...                the library will automatically find the right elements
    ...                using stored metadata, fuzzy text matching, and
    ...                semantic similarity ("Login" vs "Sign In").
    [Tags]             smoke    login    healing
    Navigate To Login Page
    # Type username – heals automatically if id=username no longer exists
    Heal Input Text    ${LOC_USERNAME}    testuser@example.com
    ...    locator_key=username_field    timeout=10
    # Type password
    Heal Input Text    ${LOC_PASSWORD}    SecurePassword123!
    ...    locator_key=password_field    timeout=10
    # Click login button – even if it changed from "Login" to "Sign In"
    Heal Click Element    ${LOC_LOGIN_BTN}
    ...    locator_key=login_button    timeout=10
    # Verify we are on the dashboard
    Page Should Contain    Dashboard

TC03 - Submit Form Button Healing
    [Documentation]    Demonstrate healing of a submit button whose text
    ...                changed from "Login" to "Continue" after a UI refresh.
    [Tags]             login    healing    semantic
    Navigate To Login Page
    Heal Input Text    ${LOC_USERNAME}    testuser@example.com    locator_key=username_field
    Heal Input Text    ${LOC_PASSWORD}    SecurePassword123!    locator_key=password_field
    # Submit button may now say "Continue" instead of "Sign In"
    # Semantic matching will still find it
    Heal Click Element    ${LOC_SUBMIT}    locator_key=submit_button

TC04 - Read Page Heading
    [Documentation]    Retrieve text from an element that may have moved.
    [Tags]             get_text    healing
    Navigate To Dashboard
    ${heading}=    Heal Get Text    ${LOC_PAGE_HEADING}
    ...    locator_key=page_heading    timeout=10
    Log    Page heading: ${heading}
    Should Not Be Empty    ${heading}

TC05 - Search Field With Healing
    [Documentation]    Type into a search box, tolerating locator changes.
    [Tags]             search    healing
    Navigate To Dashboard
    Register Locator    ${LOC_SEARCH}    search_input
    Heal Input Text    ${LOC_SEARCH}    robot framework
    ...    locator_key=search_input    timeout=10
    Keyboard Key    RETURN

TC06 - Logout With Self-Healing
    [Documentation]    Healing across a navigation link.
    [Tags]             logout    healing
    Navigate To Dashboard
    Heal Click Element    ${LOC_LOGOUT}    locator_key=logout_link

TC07 - View Healing Statistics
    [Documentation]    Inspect how many heals have occurred and confidence.
    [Tags]             diagnostics    stats
    ${all_stats}=    Get Healing Stats
    Log    All healing stats: ${all_stats}
    ${btn_stats}=    Get Healing Stats    login_button
    Log    Login button heal count: ${btn_stats}[heal_count]
    Log    Average confidence: ${btn_stats}[average_confidence]

TC08 - Locator Key Auto-Derived From Locator String
    [Documentation]    When locator_key is omitted, the library derives one
    ...                from the locator string. This test shows that healing
    ...                works even without explicit key registration.
    [Tags]             healing    no_key
    Navigate To Login Page
    # No locator_key supplied; library derives "id_username_field" automatically
    Heal Click Element    id=forgot-password-link    timeout=10

*** Keywords ***

Open Browser And Navigate
    [Documentation]    Open browser and navigate to the base URL.
    Open Browser    ${BASE_URL}    ${BROWSER}
    Set Selenium Speed    0.2s
    Maximize Browser Window

Navigate To Login Page
    Go To    ${BASE_URL}/login
    Wait Until Page Contains Element    tag=form    timeout=${TIMEOUT}

Navigate To Dashboard
    Go To    ${BASE_URL}/dashboard
    Wait Until Page Contains Element    tag=main    timeout=${TIMEOUT}
