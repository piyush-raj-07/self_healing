"""
setup.py
--------
Install the self_healing_library package into an existing Robot Framework project.

Quick start:
  pip install -e .                 # editable install (recommended for dev)
  pip install .                    # production install

Or install directly from a requirements.txt:
  pip install -r requirements.txt
"""

from setuptools import setup, find_packages

setup(
    name="self-healing-library",
    version="1.0.0",
    description=(
        "Self-healing Robot Framework library for Selenium-based UI tests. "
        "Automatically repairs broken locators using fuzzy matching and "
        "semantic similarity."
    ),
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Your Team",
    python_requires=">=3.8",
    packages=find_packages(exclude=["tests*", "examples*"]),
    install_requires=[
        "robotframework>=5.0",
        "robotframework-seleniumlibrary>=6.0",
        "selenium>=4.0",
        "rapidfuzz>=3.0",           # fast fuzzy matching (recommended)
    ],
    extras_require={
        "semantic": [
            "sentence-transformers>=2.2",  # semantic embedding similarity
            "torch>=2.0",                  # required by sentence-transformers
        ],
        "dev": [
            "pytest>=7.0",
            "pytest-mock>=3.0",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Framework :: Robot Framework :: Library",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Testing",
    ],
    entry_points={},
)
