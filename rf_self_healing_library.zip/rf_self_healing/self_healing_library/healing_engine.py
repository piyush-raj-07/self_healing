"""
healing_engine.py
-----------------
Orchestrates the complete self-healing flow.

Healing flow
------------
Step 1  Try the original locator directly.  If it works → done.
Step 2  Pre-healing checks: page ready, loaders gone, popup check.
Step 3  Load stored metadata for this locator from MetadataManager.
Step 4  Scan the live DOM for candidate elements (DOMScanner).
Step 5  Score all candidates against stored metadata (Scorer).
Step 6  Validate the best match using confidence thresholds.
Step 7  Execute the requested action on the healed element.
Step 8  Store the healed locator + new metadata for future runs.

If all steps fail the engine raises the original Selenium exception so
Robot Framework sees a clear failure with the original error message.
"""

import logging
import time
from typing import Any, Callable, Dict, Optional, Tuple

from selenium.common.exceptions import (
    ElementClickInterceptedException,
    ElementNotInteractableException,
    JavascriptException,
    NoSuchElementException,
    StaleElementReferenceException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement

from self_healing_library.dom_scanner import DOMScanner, snapshot_element
from self_healing_library.embedding_matcher import embed_text
from self_healing_library.metadata_manager import MetadataManager
from self_healing_library.page_state_checker import PageStateChecker
from self_healing_library.scorer import Scorer

logger = logging.getLogger(__name__)

# Confidence thresholds
HIGH_CONFIDENCE    = 0.75   # Use and store healed locator
MEDIUM_CONFIDENCE  = 0.55   # Use but warn; don't auto-store as healed
LOW_CONFIDENCE     = 0.40   # Reject – too risky

# Number of action-retry attempts
MAX_ACTION_RETRIES = 3


class HealingEngine:
    """
    Core self-healing orchestrator.

    Parameters
    ----------
    driver : WebDriver
        Active Selenium WebDriver instance.
    metadata_manager : MetadataManager
        Handles persistence of locator metadata.
    scorer : Scorer, optional
        Custom scorer; uses Scorer() defaults if not supplied.
    page_checker : PageStateChecker, optional
        Custom page-state checker.
    auto_store_threshold : float
        Minimum confidence to auto-persist a healed locator.
    enable_js_fallback : bool
        Attempt JS click if normal .click() fails.
    scan_shadow_dom : bool
        Whether to scan shadow DOM during healing.
    scan_iframes : bool
        Whether to scan iframes during healing.
    """

    def __init__(
        self,
        driver: WebDriver,
        metadata_manager: MetadataManager,
        scorer: Optional[Scorer] = None,
        page_checker: Optional[PageStateChecker] = None,
        auto_store_threshold: float = HIGH_CONFIDENCE,
        enable_js_fallback: bool = True,
        scan_shadow_dom: bool = True,
        scan_iframes: bool = True,
    ):
        self.driver = driver
        self.mm = metadata_manager
        self.scorer = scorer or Scorer()
        self.checker = page_checker or PageStateChecker(driver)
        self.auto_store_threshold = auto_store_threshold
        self.enable_js_fallback = enable_js_fallback
        self.scan_shadow_dom = scan_shadow_dom
        self.scan_iframes = scan_iframes

    # ------------------------------------------------------------------
    # Public action helpers called by Robot Framework keywords
    # ------------------------------------------------------------------

    def heal_click(
        self,
        locator: str,
        locator_key: Optional[str] = None,
        timeout: float = 10.0,
    ) -> str:
        """
        Click an element; heal the locator if the original fails.

        Returns the locator string actually used.
        """
        return self._heal_action(
            locator=locator,
            locator_key=locator_key,
            action=self._do_click,
            action_name="click",
            timeout=timeout,
        )

    def heal_input_text(
        self,
        locator: str,
        text: str,
        locator_key: Optional[str] = None,
        timeout: float = 10.0,
    ) -> str:
        """Type *text* into an element; heal if the original locator fails."""
        return self._heal_action(
            locator=locator,
            locator_key=locator_key,
            action=lambda el: self._do_input(el, text),
            action_name="input_text",
            timeout=timeout,
        )

    def heal_get_text(
        self,
        locator: str,
        locator_key: Optional[str] = None,
        timeout: float = 10.0,
    ) -> str:
        """Get text from an element; heal if the original locator fails."""
        text_result = {}

        def _get(el: WebElement):
            text_result["value"] = el.text or el.get_attribute("value") or ""

        self._heal_action(
            locator=locator,
            locator_key=locator_key,
            action=_get,
            action_name="get_text",
            timeout=timeout,
        )
        return text_result.get("value", "")

    def register_locator(self, locator: str, locator_key: str) -> None:
        """
        Snapshot the current state of *locator* and persist it.

        Call this keyword *before* the page changes to build the baseline
        metadata that healing will compare against later.
        """
        element = self._find_element(locator)
        if element is None:
            raise NoSuchElementException(
                f"register_locator: cannot find element '{locator}'"
            )
        meta = snapshot_element(element)
        # Also store embedding for the element's text
        text = meta.get("text", "")
        if text:
            vec = embed_text(text)
            meta["embedding"] = vec or []
        self.mm.store_locator_metadata(locator_key, locator, meta)
        logger.info("Registered locator '%s' → '%s'", locator_key, locator)

    # ------------------------------------------------------------------
    # Internal healing orchestration
    # ------------------------------------------------------------------

    def _heal_action(
        self,
        locator: str,
        locator_key: Optional[str],
        action: Callable[[WebElement], Any],
        action_name: str,
        timeout: float,
    ) -> str:
        """
        Full healing flow.  Returns the locator string that was used.
        """
        # ── Step 1: Try original locator ──────────────────────────────
        logger.debug("[Heal %s] Step 1 – trying original locator: %s", action_name, locator)
        try:
            element = self._find_element_with_wait(locator, timeout=min(timeout, 5.0))
            if element and self.checker.prepare_element(element):
                self._execute_action_with_retry(element, action)
                logger.debug("[Heal %s] Original locator succeeded.", action_name)
                return locator
        except (NoSuchElementException, WebDriverException) as original_exc:
            logger.info(
                "[Heal %s] Original locator '%s' failed: %s. Starting healing…",
                action_name, locator, original_exc,
            )
            last_exc = original_exc
        else:
            last_exc = Exception("Element not interactable")

        # ── Step 2: Pre-healing checks ────────────────────────────────
        logger.debug("[Heal %s] Step 2 – pre-healing page checks", action_name)
        self.checker.wait_for_page_ready()
        self.checker.wait_for_loaders_gone()
        if self.checker.check_for_popups():
            logger.warning("[Heal %s] Popup detected; healing may be affected.", action_name)

        # ── Step 3: Load stored metadata ─────────────────────────────
        key = locator_key or self._derive_key(locator)
        logger.debug("[Heal %s] Step 3 – loading metadata for key '%s'", action_name, key)

        # Try the previously healed locator first (fast path)
        healed_locator = self.mm.get_healed_locator(key)
        if healed_locator and healed_locator != locator:
            logger.info(
                "[Heal %s] Trying cached healed locator: %s", action_name, healed_locator
            )
            try:
                el = self._find_element_with_wait(healed_locator, timeout=3.0)
                if el and self.checker.prepare_element(el):
                    self._execute_action_with_retry(el, action)
                    logger.info("[Heal %s] Cached healed locator worked!", action_name)
                    return healed_locator
            except (NoSuchElementException, WebDriverException):
                logger.info("[Heal %s] Cached healed locator also failed; full scan.", action_name)

        stored_meta = self.mm.get_locator_metadata(key)
        if not stored_meta:
            logger.warning(
                "[Heal %s] No metadata for key '%s'. Consider calling Register Locator first.",
                action_name, key,
            )
            stored_meta = self._build_fallback_metadata(locator)

        # ── Step 4: Scan live DOM ─────────────────────────────────────
        logger.debug("[Heal %s] Step 4 – scanning DOM for candidates", action_name)
        scanner = DOMScanner(
            driver=self.driver,
            target_metadata=stored_meta,
            scan_shadow_dom=self.scan_shadow_dom,
            scan_iframes=self.scan_iframes,
        )
        candidates = scanner.find_candidates()
        logger.debug("[Heal %s] Found %d candidates", action_name, len(candidates))

        if not candidates:
            raise last_exc  # type: ignore[misc]

        # ── Steps 5 & 6: Score and validate ──────────────────────────
        logger.debug("[Heal %s] Steps 5/6 – scoring and validating", action_name)
        confidence, best = self.scorer.best_match(stored_meta, candidates)

        if confidence is None or best is None:
            logger.error("[Heal %s] No candidate exceeded minimum confidence.", action_name)
            raise last_exc  # type: ignore[misc]

        if confidence < MEDIUM_CONFIDENCE:
            logger.error(
                "[Heal %s] Best confidence %.2f below threshold %.2f.",
                action_name, confidence, MEDIUM_CONFIDENCE,
            )
            raise last_exc  # type: ignore[misc]

        logger.info(
            "[Heal %s] Best match confidence=%.2f  tag=%s  text='%s'  id='%s'",
            action_name,
            confidence,
            best.get("tag"),
            best.get("text", "")[:40],
            best.get("id", ""),
        )

        # ── Step 7: Execute action ────────────────────────────────────
        logger.debug("[Heal %s] Step 7 – executing action on healed element", action_name)
        healed_el = best["element"]
        iframe_needed = best.get("in_iframe", False)
        iframe_idx = best.get("iframe_index")

        if iframe_needed and iframe_idx is not None:
            iframes = self.driver.find_elements(By.TAG_NAME, "iframe")
            if iframe_idx < len(iframes):
                self.driver.switch_to.frame(iframes[iframe_idx])

        try:
            self.checker.prepare_element(healed_el)
            self._execute_action_with_retry(healed_el, action)
        finally:
            if iframe_needed:
                try:
                    self.driver.switch_to.default_content()
                except WebDriverException:
                    pass

        # ── Step 8: Store healed locator ──────────────────────────────
        if confidence >= self.auto_store_threshold:
            new_locator = best.get("xpath", locator)
            embedding = embed_text(best.get("text", ""))
            self.mm.store_healed_locator(key, new_locator, confidence, embedding)
            logger.info(
                "[Heal %s] Step 8 – stored healed locator '%s' (confidence=%.2f)",
                action_name, new_locator, confidence,
            )
            return new_locator
        else:
            logger.info(
                "[Heal %s] Confidence %.2f below auto-store threshold %.2f – not persisted.",
                action_name, confidence, self.auto_store_threshold,
            )

        return best.get("xpath", locator)

    # ------------------------------------------------------------------
    # Action execution with retry and JS fallback
    # ------------------------------------------------------------------

    def _execute_action_with_retry(
        self,
        element: WebElement,
        action: Callable[[WebElement], Any],
    ) -> None:
        """
        Attempt *action* on *element* up to MAX_ACTION_RETRIES times.
        Falls back to JavaScript click on ElementClickInterceptedException
        if self.enable_js_fallback is True.
        """
        last_exc: Optional[Exception] = None
        for attempt in range(1, MAX_ACTION_RETRIES + 1):
            try:
                action(element)
                return
            except ElementClickInterceptedException as exc:
                logger.warning(
                    "Click intercepted (attempt %d/%d)", attempt, MAX_ACTION_RETRIES
                )
                last_exc = exc
                if self.enable_js_fallback:
                    try:
                        self._js_click(element)
                        return
                    except (JavascriptException, WebDriverException):
                        pass
            except ElementNotInteractableException as exc:
                logger.warning(
                    "Element not interactable (attempt %d/%d)", attempt, MAX_ACTION_RETRIES
                )
                last_exc = exc
                time.sleep(0.5 * attempt)
            except StaleElementReferenceException as exc:
                logger.warning(
                    "Stale element reference (attempt %d/%d)", attempt, MAX_ACTION_RETRIES
                )
                last_exc = exc
                break  # element is gone – no point retrying
        raise last_exc or Exception("Action failed after retries")

    def _js_click(self, element: WebElement) -> None:
        """JavaScript fallback click."""
        self.driver.execute_script("arguments[0].click();", element)
        logger.info("JS fallback click used.")

    # ------------------------------------------------------------------
    # Element-finding helpers
    # ------------------------------------------------------------------

    def _find_element(self, locator: str) -> Optional[WebElement]:
        """Resolve a SeleniumLibrary-style locator string to a WebElement."""
        by, value = self._parse_locator(locator)
        try:
            return self.driver.find_element(by, value)
        except (NoSuchElementException, WebDriverException):
            return None

    def _find_element_with_wait(
        self, locator: str, timeout: float = 5.0
    ) -> Optional[WebElement]:
        """Like _find_element but polls for *timeout* seconds."""
        by, value = self._parse_locator(locator)
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                return self.driver.find_element(by, value)
            except NoSuchElementException:
                time.sleep(0.3)
            except WebDriverException:
                return None
        return None

    @staticmethod
    def _parse_locator(locator: str) -> Tuple[str, str]:
        """
        Convert SeleniumLibrary locator syntax to (By, value) tuple.

        Supported prefixes: id=, name=, xpath=, css=, class=,
                            tag=, link=, partial link=
        No prefix → treated as id first, then xpath.
        """
        if "=" in locator:
            prefix, _, value = locator.partition("=")
            prefix = prefix.strip().lower()
            mapping = {
                "id":           By.ID,
                "name":         By.NAME,
                "xpath":        By.XPATH,
                "css":          By.CSS_SELECTOR,
                "class":        By.CLASS_NAME,
                "tag":          By.TAG_NAME,
                "link":         By.LINK_TEXT,
                "partial link": By.PARTIAL_LINK_TEXT,
            }
            if prefix in mapping:
                return mapping[prefix], value.strip()
        # Default: try as xpath if it starts with //, else as id
        if locator.startswith("//") or locator.startswith("(//"):
            return By.XPATH, locator
        return By.ID, locator

    # ------------------------------------------------------------------
    # Misc helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _derive_key(locator: str) -> str:
        """
        Derive a metadata key from a locator string.
        e.g.  "id=login-btn"  → "login_btn"
              "xpath=//button[@text='Login']" → "xpath____button__text__Login__"
        """
        import re
        _, _, value = locator.partition("=")
        return re.sub(r"[^a-zA-Z0-9_]", "_", value)[:60]

    @staticmethod
    def _build_fallback_metadata(locator: str) -> Dict[str, Any]:
        """
        Build a minimal metadata dict when no stored data is available.
        Extracts hints from the locator string itself.
        """
        meta: Dict[str, Any] = {
            "tag": "*", "text": "", "id": "",
            "name": "", "classes": [], "aria_label": "",
            "placeholder": "", "embedding": [],
        }
        if "=" in locator:
            prefix, _, value = locator.partition("=")
            prefix = prefix.strip().lower()
            if prefix == "id":
                meta["id"] = value
            elif prefix == "name":
                meta["name"] = value
            elif prefix in ("link", "partial link"):
                meta["text"] = value
                meta["tag"] = "a"
        return meta

    @staticmethod
    def _do_click(element: WebElement) -> None:
        element.click()

    @staticmethod
    def _do_input(element: WebElement, text: str) -> None:
        element.clear()
        element.send_keys(text)
