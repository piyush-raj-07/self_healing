"""
metadata_manager.py
-------------------
Handles all persistence for the self-healing library.

Responsibilities:
  - Load / save locator_metadata.json from disk
  - Store "healed" locators so subsequent runs use the better locator first
  - Record embedding vectors alongside each locator entry
  - Track confidence history so we can spot degrading locators over time
  - Prune stale history entries to keep the file size manageable

JSON schema (one entry per logical locator name):
{
  "login_button": {
    "original_locator": "id=login-btn",
    "healed_locator": "xpath=//button[text()='Sign In']",
    "tag": "button",
    "text": "Sign In",
    "name": "",
    "classes": ["btn", "btn-primary"],
    "aria_label": "Sign in to your account",
    "placeholder": "",
    "attributes": {"data-testid": "login-btn"},
    "xpath_path": "//html/body/div[1]/form/button",
    "parent_tag": "form",
    "parent_id": "login-form",
    "embedding": [0.12, -0.34, ...],          # 384-dim float list or []
    "confidence_history": [0.95, 0.87, 0.91], # last N confidence scores
    "last_healed": "2024-01-15T10:30:00",
    "heal_count": 3
  }
}
"""

import json
import os
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Maximum number of past confidence scores to keep per locator
MAX_HISTORY_LENGTH = 20


class MetadataManager:
    """
    Manages locator metadata persistence.

    All read/write operations go through this class so the rest of the
    library never touches the JSON file directly.
    """

    def __init__(self, metadata_path: str = "locator_metadata.json"):
        """
        Parameters
        ----------
        metadata_path : str
            Absolute or relative path to the JSON metadata file.
            Created automatically if it does not exist.
        """
        self.metadata_path = os.path.abspath(metadata_path)
        self._data: Dict[str, Any] = {}
        self._load()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_locator_metadata(self, locator_key: str) -> Optional[Dict[str, Any]]:
        """
        Return the stored metadata dict for *locator_key*, or None.

        Parameters
        ----------
        locator_key : str
            The logical name registered for this locator, e.g. "login_button".
        """
        return self._data.get(locator_key)

    def store_locator_metadata(
        self,
        locator_key: str,
        original_locator: str,
        metadata: Dict[str, Any],
    ) -> None:
        """
        Persist fresh metadata captured from the live DOM.

        Called by ``SelfHealingLibrary.register_locator`` and after a
        successful heal so future runs start with better baseline data.

        Parameters
        ----------
        locator_key : str
            Logical name for this locator.
        original_locator : str
            The locator string as written in the .robot file.
        metadata : dict
            DOM snapshot: tag, text, classes, attributes, etc.
        """
        entry = self._data.get(locator_key, {})
        entry.update(metadata)
        entry["original_locator"] = original_locator
        entry.setdefault("confidence_history", [])
        entry.setdefault("heal_count", 0)
        entry.setdefault("embedding", [])
        self._data[locator_key] = entry
        self._save()
        logger.debug("Stored metadata for '%s'", locator_key)

    def store_healed_locator(
        self,
        locator_key: str,
        healed_locator: str,
        confidence: float,
        embedding: Optional[list] = None,
    ) -> None:
        """
        Record a successfully healed locator so the next run uses it.

        Parameters
        ----------
        locator_key : str
            Logical name for this locator.
        healed_locator : str
            The new locator string that worked (e.g. "xpath=//button[…]").
        confidence : float
            Confidence score (0–1) of the match that produced this locator.
        embedding : list, optional
            Sentence-embedding vector of the element's visible text.
        """
        entry = self._data.setdefault(locator_key, {})
        entry["healed_locator"] = healed_locator
        entry["last_healed"] = datetime.now(timezone.utc).isoformat()
        entry["heal_count"] = entry.get("heal_count", 0) + 1

        # Append confidence to rolling history, capped at MAX_HISTORY_LENGTH
        history = entry.setdefault("confidence_history", [])
        history.append(round(confidence, 4))
        if len(history) > MAX_HISTORY_LENGTH:
            entry["confidence_history"] = history[-MAX_HISTORY_LENGTH:]

        if embedding is not None:
            entry["embedding"] = embedding

        self._data[locator_key] = entry
        self._save()
        logger.info(
            "Healed locator stored for '%s' → %s (confidence=%.2f)",
            locator_key,
            healed_locator,
            confidence,
        )

    def get_healed_locator(self, locator_key: str) -> Optional[str]:
        """Return the previously healed locator for *locator_key*, or None."""
        entry = self._data.get(locator_key, {})
        return entry.get("healed_locator")

    def get_stored_embedding(self, locator_key: str) -> Optional[list]:
        """Return the stored embedding vector for *locator_key*, or None."""
        entry = self._data.get(locator_key, {})
        vec = entry.get("embedding", [])
        return vec if vec else None

    def get_average_confidence(self, locator_key: str) -> float:
        """
        Return the mean of the last N confidence scores for *locator_key*.
        Returns 0.0 if no history exists.
        """
        entry = self._data.get(locator_key, {})
        history = entry.get("confidence_history", [])
        return sum(history) / len(history) if history else 0.0

    def all_keys(self):
        """Yield all registered locator keys."""
        yield from self._data.keys()

    def export_snapshot(self) -> Dict[str, Any]:
        """Return a deep-copy snapshot of all metadata (for debugging)."""
        import copy
        return copy.deepcopy(self._data)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load(self) -> None:
        """Load metadata from disk; create an empty file if missing."""
        if os.path.exists(self.metadata_path):
            try:
                with open(self.metadata_path, "r", encoding="utf-8") as fh:
                    self._data = json.load(fh)
                logger.info(
                    "Loaded metadata from %s (%d entries)",
                    self.metadata_path,
                    len(self._data),
                )
            except (json.JSONDecodeError, OSError) as exc:
                logger.warning(
                    "Could not read metadata file (%s); starting fresh.", exc
                )
                self._data = {}
        else:
            logger.info(
                "Metadata file not found at %s; will create on first save.",
                self.metadata_path,
            )
            self._data = {}

    def _save(self) -> None:
        """Atomically write metadata to disk."""
        os.makedirs(os.path.dirname(self.metadata_path) or ".", exist_ok=True)
        tmp_path = self.metadata_path + ".tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as fh:
                json.dump(self._data, fh, indent=2, ensure_ascii=False)
            os.replace(tmp_path, self.metadata_path)
        except OSError as exc:
            logger.error("Failed to save metadata: %s", exc)
