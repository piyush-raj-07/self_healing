"""
self_healing_library
--------------------
Self-healing Robot Framework library for Selenium-based UI tests.

Import the library in your .robot file:

    Library    self_healing_library.SelfHealingLibrary
    ...    metadata_path=locator_metadata.json

Or import the main class directly in Python:

    from self_healing_library import SelfHealingLibrary
"""

from self_healing_library.SelfHealingLibrary import SelfHealingLibrary

__all__ = ["SelfHealingLibrary"]
__version__ = "1.0.0"
