"""
SelfHealingLibrary.py
---------------------
Robot Framework library that exposes self-healing keywords.

Usage in .robot files
---------------------
    Library    self_healing_library.SelfHealingLibrary
    ...    metadata_path=locator_metadata.json
    ...    confidence_threshold=0.60
    ...    enable_js_fallback=${True}
    ...    scan_iframes=${True}
    ...    scan_shadow_dom=${True}

Keywords
--------
Register Locator
    Snapshot and persist the current state of a locator.
    Call BEFORE page changes to build the healing baseline.

Heal Click Element
    Click an element, healing the locator if needed.

Heal Input Text
    Type text into a field, healing the locator if needed.

Heal Get Text
    Retrieve text from an element, healing the locator if needed.

Get Healing Stats
    Return a dict with heal_count and average_confidence per key.

Notes
-----
• The library hooks into SeleniumLibrary's WebDriver via the
  ``driver`` property of the ``SeleniumLibrary`` instance that must
  already be imported in the test suite.

• All keywords accept an optional ``locator_key`` argument.  When
  omitted the key is derived automatically from the locator string.
  Explicit keys are recommended for maintainability.

• Thread-safety: each Robot Framework session creates its own library
  instance; no global state is shared between parallel sessions.
"""

import logging
import os
from typing import Optional

from robot.api.deco import keyword, library
from robot.libraries.BuiltIn import BuiltIn

from self_healing_library.healing_engine import HealingEngine
from self_healing_library.metadata_manager import MetadataManager
from self_healing_library.page_state_checker import PageStateChecker
from self_healing_library.scorer import Scorer

# Configure a module-level logger; Robot Framework handlers are added
# automatically when the library is loaded in a test run.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(name)s  %(levelname)s  %(message)s",
)
logger = logging.getLogger(__name__)

__version__ = "1.0.0"
ROBOT_LIBRARY_SCOPE = "SUITE"
ROBOT_LIBRARY_VERSION = __version__


@library(scope="SUITE", version=__version__)
class SelfHealingLibrary:
    """
    Self-Healing Robot Framework library for Selenium-based tests.

    Automatically detects broken locators and attempts to find the
    correct element using fuzzy matching, semantic embeddings, and
    multi-strategy DOM scanning.
    """

    ROBOT_LIBRARY_DOC_FORMAT = "reST"

    def __init__(
        self,
        metadata_path: str = "locator_metadata.json",
        confidence_threshold: float = 0.60,
        auto_store_threshold: float = 0.75,
        enable_js_fallback: bool = True,
        scan_iframes: bool = True,
        scan_shadow_dom: bool = True,
        page_ready_timeout: float = 10.0,
        max_candidates: int = 50,
        semantic_blend: float = 0.20,
    ):
        """
        Initialise the SelfHealingLibrary.

        Parameters
        ----------
        metadata_path : str
            Path to the JSON file that stores locator metadata and
            healing history.  Created automatically if missing.
        confidence_threshold : float
            Minimum confidence (0–1) to accept a healed locator.
        auto_store_threshold : float
            Minimum confidence to auto-save a healed locator for
            future runs.  Must be ≥ confidence_threshold.
        enable_js_fallback : bool
            Use JavaScript click when normal click is intercepted.
        scan_iframes : bool
            Whether to search inside <iframe> elements.
        scan_shadow_dom : bool
            Whether to pierce shadow DOM during healing.
        page_ready_timeout : float
            Seconds to wait for page-ready checks.
        max_candidates : int
            Upper limit on DOM candidates per healing attempt.
        semantic_blend : float
            Weight of semantic embedding similarity in the final score.
        """
        self.metadata_path = metadata_path
        self.confidence_threshold = confidence_threshold
        self.auto_store_threshold = max(confidence_threshold, auto_store_threshold)
        self.enable_js_fallback = enable_js_fallback
        self.scan_iframes = scan_iframes
        self.scan_shadow_dom = scan_shadow_dom
        self.page_ready_timeout = page_ready_timeout
        self.max_candidates = max_candidates
        self.semantic_blend = semantic_blend

        # These are created lazily on first keyword call (driver not yet
        # available during __init__)
        self._mm: Optional[MetadataManager] = None
        self._engine: Optional[HealingEngine] = None

    # ------------------------------------------------------------------
    # Robot Framework Keywords
    # ------------------------------------------------------------------

    @keyword("Register Locator")
    def register_locator(self, locator: str, locator_key: str) -> None:
        """
        Snapshot the element identified by *locator* and persist its
        metadata under *locator_key* in the metadata JSON file.

        Call this keyword early in your test setup *before* any page
        changes occur so the library has a baseline to compare against
        during healing.

        Example
        -------
        ::

            Register Locator    id=login-btn    login_button
        """
        engine = self._get_engine()
        engine.register_locator(locator, locator_key)
        logger.info("Registered locator '%s' as '%s'", locator, locator_key)

    @keyword("Heal Click Element")
    def heal_click_element(
        self,
        locator: str,
        locator_key: Optional[str] = None,
        timeout: float = 10.0,
    ) -> str:
        """
        Click the element identified by *locator*.

        If the original locator fails, the library will scan the DOM,
        score candidates, and click the best match automatically.

        Parameters
        ----------
        locator : str
            SeleniumLibrary-style locator (e.g. ``id=login-btn``,
            ``xpath=//button[@text='Login']``, ``css=.btn-primary``).
        locator_key : str, optional
            Logical name for this locator in the metadata file.
            Recommended for stable healing across page changes.
        timeout : float
            Seconds to wait when searching for the element.

        Returns
        -------
        str
            The locator string that was actually used (original or healed).

        Example
        -------
        ::

            Heal Click Element    id=login-btn    locator_key=login_button
        """
        engine = self._get_engine()
        used_locator = engine.heal_click(locator, locator_key, timeout)
        logger.info("Heal Click Element done. Used locator: %s", used_locator)
        return used_locator

    @keyword("Heal Input Text")
    def heal_input_text(
        self,
        locator: str,
        text: str,
        locator_key: Optional[str] = None,
        timeout: float = 10.0,
    ) -> str:
        """
        Type *text* into the input element identified by *locator*.

        If the original locator fails, the library heals it automatically.

        Parameters
        ----------
        locator : str
            SeleniumLibrary-style locator.
        text : str
            The text to type into the input field.
        locator_key : str, optional
            Logical name for this locator in the metadata file.
        timeout : float
            Seconds to wait when searching for the element.

        Returns
        -------
        str
            The locator string actually used.

        Example
        -------
        ::

            Heal Input Text    id=username    john@example.com    locator_key=username_field
        """
        engine = self._get_engine()
        used_locator = engine.heal_input_text(locator, text, locator_key, timeout)
        logger.info("Heal Input Text done. Used locator: %s", used_locator)
        return used_locator

    @keyword("Heal Get Text")
    def heal_get_text(
        self,
        locator: str,
        locator_key: Optional[str] = None,
        timeout: float = 10.0,
    ) -> str:
        """
        Retrieve the visible text from the element identified by *locator*.

        If the original locator fails, the library heals it automatically.

        Parameters
        ----------
        locator : str
            SeleniumLibrary-style locator.
        locator_key : str, optional
            Logical name for this locator in the metadata file.
        timeout : float
            Seconds to wait when searching for the element.

        Returns
        -------
        str
            The visible text (or ``value`` attribute for inputs).

        Example
        -------
        ::

            ${heading}=    Heal Get Text    css=h1.page-title    locator_key=page_heading
        """
        engine = self._get_engine()
        result = engine.heal_get_text(locator, locator_key, timeout)
        logger.info("Heal Get Text returned: %s", result[:80] if result else "(empty)")
        return result

    @keyword("Get Healing Stats")
    def get_healing_stats(self, locator_key: Optional[str] = None) -> dict:
        """
        Return healing statistics for *locator_key* (or all keys if omitted).

        Example
        -------
        ::

            ${stats}=    Get Healing Stats    login_button
            Log    Heal count: ${stats}[heal_count]
        """
        mm = self._get_metadata_manager()
        if locator_key:
            meta = mm.get_locator_metadata(locator_key) or {}
            return {
                "key":                locator_key,
                "heal_count":         meta.get("heal_count", 0),
                "healed_locator":     meta.get("healed_locator", ""),
                "average_confidence": mm.get_average_confidence(locator_key),
                "last_healed":        meta.get("last_healed", ""),
            }
        # Aggregate all keys
        result = {}
        for key in mm.all_keys():
            meta = mm.get_locator_metadata(key) or {}
            result[key] = {
                "heal_count":         meta.get("heal_count", 0),
                "healed_locator":     meta.get("healed_locator", ""),
                "average_confidence": mm.get_average_confidence(key),
            }
        return result

    # ------------------------------------------------------------------
    # Internal lazy initialisation
    # ------------------------------------------------------------------

    def _get_metadata_manager(self) -> MetadataManager:
        if self._mm is None:
            self._mm = MetadataManager(self.metadata_path)
        return self._mm

    def _get_engine(self) -> HealingEngine:
        """
        Lazily create the HealingEngine, pulling the WebDriver from
        the already-imported SeleniumLibrary instance.
        """
        if self._engine is not None:
            return self._engine

        driver = self._get_driver()
        mm = self._get_metadata_manager()
        scorer = Scorer(
            min_confidence=self.confidence_threshold,
            semantic_blend=self.semantic_blend,
        )
        checker = PageStateChecker(
            driver=driver,
            page_ready_timeout=self.page_ready_timeout,
        )
        self._engine = HealingEngine(
            driver=driver,
            metadata_manager=mm,
            scorer=scorer,
            page_checker=checker,
            auto_store_threshold=self.auto_store_threshold,
            enable_js_fallback=self.enable_js_fallback,
            scan_shadow_dom=self.scan_shadow_dom,
            scan_iframes=self.scan_iframes,
        )
        return self._engine

    @staticmethod
    def _get_driver():
        """
        Retrieve the active WebDriver from the SeleniumLibrary instance
        that is already imported in the current Robot Framework test suite.

        Raises RuntimeError if SeleniumLibrary is not available.
        """
        try:
            builtin = BuiltIn()
            selenium_lib = builtin.get_library_instance("SeleniumLibrary")
            return selenium_lib.driver
        except Exception as exc:
            raise RuntimeError(
                "SelfHealingLibrary requires SeleniumLibrary to be imported "
                "and a browser to be open before calling healing keywords. "
                f"Original error: {exc}"
            ) from exc
