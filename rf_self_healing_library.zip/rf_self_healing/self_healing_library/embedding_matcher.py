"""
embedding_matcher.py
--------------------
Semantic similarity via sentence embeddings.

This module adds an *extra signal* beyond fuzzy string matching: it can
recognise that "Login", "Sign In", and "Continue" are semantically
related even though they share no characters.

Model strategy
--------------
We use ``sentence-transformers`` with the small, fast model
``all-MiniLM-L6-v2`` (22 MB, 384-dim).  If the package is not installed
the module silently falls back to returning 0.0 for all embedding
comparisons so the rest of the library keeps working without ML deps.

Caching
-------
Embeddings are cached in memory for the lifetime of the process and
persisted in ``locator_metadata.json`` (via MetadataManager) so we only
run the model once per unique text string.
"""

import logging
import math
from typing import List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional heavy import – graceful degradation
# ---------------------------------------------------------------------------
try:
    from sentence_transformers import SentenceTransformer  # type: ignore

    _MODEL_NAME = "all-MiniLM-L6-v2"
    _model: Optional["SentenceTransformer"] = None          # lazy-loaded

    def _get_model() -> "SentenceTransformer":
        global _model
        if _model is None:
            logger.info("Loading sentence-transformer model '%s'…", _MODEL_NAME)
            _model = SentenceTransformer(_MODEL_NAME)
        return _model

    _EMBEDDINGS_AVAILABLE = True
    logger.debug("embedding_matcher: sentence-transformers available")

except ImportError:
    _EMBEDDINGS_AVAILABLE = False
    logger.info(
        "embedding_matcher: sentence-transformers not installed – "
        "semantic similarity will be skipped."
    )


# ---------------------------------------------------------------------------
# In-process embedding cache:  text -> List[float]
# ---------------------------------------------------------------------------
_EMBED_CACHE: dict = {}


def embed_text(text: str) -> Optional[List[float]]:
    """
    Return a 384-dim embedding for *text*, or None if unavailable.

    Results are cached in-process.
    """
    if not _EMBEDDINGS_AVAILABLE or not text:
        return None
    if text in _EMBED_CACHE:
        return _EMBED_CACHE[text]
    try:
        model = _get_model()
        vec = model.encode(text, normalize_embeddings=True).tolist()
        _EMBED_CACHE[text] = vec
        return vec
    except Exception as exc:                         # noqa: BLE001
        logger.warning("Embedding failed for '%s': %s", text, exc)
        return None


def cosine_similarity(a: List[float], b: List[float]) -> float:
    """
    Return cosine similarity between two vectors in [−1, 1].
    Clipped to [0, 1] because embeddings are normalised (all values ≥ 0).
    """
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return max(0.0, min(1.0, dot / (norm_a * norm_b)))


def semantic_similarity(
    text_a: str,
    text_b: str,
    stored_embedding: Optional[List[float]] = None,
) -> float:
    """
    Compute semantic similarity between two text strings.

    If *stored_embedding* is supplied (pre-computed vector from metadata)
    we skip re-encoding text_a, saving one model call.

    Parameters
    ----------
    text_a : str
        The stored / reference text (e.g. from metadata JSON).
    text_b : str
        The candidate element's visible text.
    stored_embedding : list, optional
        Pre-computed embedding for text_a.

    Returns
    -------
    float
        Similarity in [0, 1].  Returns 0.0 if embeddings are unavailable.
    """
    if not _EMBEDDINGS_AVAILABLE:
        return 0.0

    if not text_a and not text_b:
        return 1.0
    if not text_a or not text_b:
        return 0.0

    vec_a = stored_embedding if stored_embedding else embed_text(text_a)
    vec_b = embed_text(text_b)

    if vec_a is None or vec_b is None:
        return 0.0

    return round(cosine_similarity(vec_a, vec_b), 4)


def embeddings_available() -> bool:
    """Return True if sentence-transformers is installed and the model loads."""
    return _EMBEDDINGS_AVAILABLE
