"""
dom_scanner.py
--------------
Scans the live browser DOM and returns candidate elements for healing.

Scanning strategies (applied in order, results merged and de-duplicated):
  1. Tag + text content   – finds elements whose visible text matches
  2. Attribute sweep      – looks for id / name / aria-label / placeholder
  3. Class overlap        – elements sharing CSS classes
  4. XPath ancestor path  – structural xpath similarity
  5. Shadow DOM           – pierces shadow roots via JavaScript
  6. iframe contexts      – switches to each iframe and repeats

Each candidate is returned as a dict with enough information for the
Scorer to rank it without making additional Selenium calls.
"""

import logging
import re
from typing import Any, Dict, List, Optional

from selenium.common.exceptions import (
    JavascriptException,
    NoSuchFrameException,
    StaleElementReferenceException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement

logger = logging.getLogger(__name__)

# Tags that are unlikely to be interactive and can be deprioritised
_SKIP_TAGS = {"script", "style", "meta", "head", "html", "noscript"}

# Regex that spots IDs / class names that look auto-generated
_DYNAMIC_ID_RE = re.compile(
    r"(?:"
    r"\d{3,}"          # 3+ consecutive digits
    r"|[a-f0-9]{8,}"   # long hex strings (React keys, etc.)
    r"|_[a-z]{2,6}\d{2,}"  # _abc12, _comp34 patterns
    r")",
    re.IGNORECASE,
)


def is_dynamic_identifier(value: str) -> bool:
    """Return True if *value* looks like an auto-generated id/class."""
    return bool(_DYNAMIC_ID_RE.search(value))


class DOMScanner:
    """
    Responsible for finding candidate WebElements from the live page.

    Parameters
    ----------
    driver : WebDriver
        Active Selenium WebDriver instance.
    target_metadata : dict
        Metadata snapshot of the *original* element (tag, text, classes…).
        Used to narrow the search space.
    scan_shadow_dom : bool
        Whether to pierce shadow roots (adds JS overhead).
    scan_iframes : bool
        Whether to switch into iframes during scanning.
    max_candidates : int
        Upper limit of candidates returned (performance guard).
    """

    def __init__(
        self,
        driver: WebDriver,
        target_metadata: Dict[str, Any],
        scan_shadow_dom: bool = True,
        scan_iframes: bool = True,
        max_candidates: int = 50,
    ):
        self.driver = driver
        self.target = target_metadata
        self.scan_shadow_dom = scan_shadow_dom
        self.scan_iframes = scan_iframes
        self.max_candidates = max_candidates

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def find_candidates(self) -> List[Dict[str, Any]]:
        """
        Run all scanning strategies and return a deduplicated list of
        candidate dicts ready for the Scorer.

        Each dict has the shape:
          {
            "element":    WebElement,
            "tag":        str,
            "text":       str,
            "id":         str,
            "name":       str,
            "classes":    List[str],
            "aria_label": str,
            "placeholder":str,
            "attributes": Dict[str, str],
            "xpath":      str,         # best-effort generated xpath
            "in_iframe":  bool,
            "iframe_index": int | None,
            "in_shadow":  bool,
          }
        """
        seen_ids: set = set()
        candidates: List[Dict[str, Any]] = []

        # --- main document ---
        self._collect_from_context(candidates, seen_ids, in_iframe=False)

        # --- iframes ---
        if self.scan_iframes:
            self._collect_from_iframes(candidates, seen_ids)

        # --- shadow DOM ---
        if self.scan_shadow_dom:
            self._collect_from_shadow(candidates, seen_ids)

        logger.debug("DOM scan found %d candidates", len(candidates))
        return candidates[: self.max_candidates]

    # ------------------------------------------------------------------
    # Strategy implementations
    # ------------------------------------------------------------------

    def _collect_from_context(
        self,
        candidates: List[Dict[str, Any]],
        seen_ids: set,
        in_iframe: bool,
        iframe_index: Optional[int] = None,
    ) -> None:
        """Gather candidates from the currently active document context."""
        target_tag = self.target.get("tag", "*") or "*"

        # Strategy 1: elements with matching tag
        try:
            elements = self.driver.find_elements(By.TAG_NAME, target_tag)
        except WebDriverException:
            elements = []

        for el in elements:
            self._try_add(candidates, seen_ids, el, in_iframe, iframe_index, False)

        # Strategy 2: text-based search for the target label/button text
        target_text = self.target.get("text", "").strip()
        if target_text:
            for by, expr in self._text_locators(target_text, target_tag):
                try:
                    for el in self.driver.find_elements(by, expr):
                        self._try_add(
                            candidates, seen_ids, el, in_iframe, iframe_index, False
                        )
                except WebDriverException:
                    pass

        # Strategy 3: attribute-based shortcuts
        for attr, value in [
            ("id",           self.target.get("id", "")),
            ("name",         self.target.get("name", "")),
            ("aria-label",   self.target.get("aria_label", "")),
            ("placeholder",  self.target.get("placeholder", "")),
            ("data-testid",  self.target.get("attributes", {}).get("data-testid", "")),
        ]:
            if not value:
                continue
            try:
                for el in self.driver.find_elements(
                    By.XPATH, f"//{target_tag}[@{attr}]"
                ):
                    self._try_add(
                        candidates, seen_ids, el, in_iframe, iframe_index, False
                    )
            except WebDriverException:
                pass

        # Strategy 4: class-based search
        for cls in self.target.get("classes", []):
            if not cls or is_dynamic_identifier(cls):
                continue
            try:
                for el in self.driver.find_elements(By.CLASS_NAME, cls):
                    self._try_add(
                        candidates, seen_ids, el, in_iframe, iframe_index, False
                    )
            except WebDriverException:
                pass

    def _collect_from_iframes(
        self,
        candidates: List[Dict[str, Any]],
        seen_ids: set,
    ) -> None:
        """Switch into each iframe, collect candidates, then switch back."""
        try:
            iframes = self.driver.find_elements(By.TAG_NAME, "iframe")
        except WebDriverException:
            return

        for idx, iframe in enumerate(iframes):
            try:
                self.driver.switch_to.frame(iframe)
                self._collect_from_context(candidates, seen_ids, True, idx)
                self.driver.switch_to.default_content()
            except (NoSuchFrameException, WebDriverException) as exc:
                logger.debug("Skipping iframe %d: %s", idx, exc)
                try:
                    self.driver.switch_to.default_content()
                except WebDriverException:
                    pass

    def _collect_from_shadow(
        self,
        candidates: List[Dict[str, Any]],
        seen_ids: set,
    ) -> None:
        """
        Use JavaScript to pierce shadow roots and collect elements.
        Only one level of shadow root is pierced; recursive piercing is
        intentionally skipped for performance reasons.
        """
        js = """
        const results = [];
        const hosts = document.querySelectorAll('*');
        for (const h of hosts) {
            if (h.shadowRoot) {
                const tag = arguments[0];
                const els = tag === '*'
                    ? h.shadowRoot.querySelectorAll('*')
                    : h.shadowRoot.querySelectorAll(tag);
                for (const e of els) results.push(e);
            }
        }
        return results;
        """
        target_tag = self.target.get("tag", "*") or "*"
        try:
            shadow_elements = self.driver.execute_script(js, target_tag) or []
            for el in shadow_elements:
                self._try_add(candidates, seen_ids, el, False, None, True)
        except JavascriptException as exc:
            logger.debug("Shadow DOM scan failed: %s", exc)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _try_add(
        self,
        candidates: List[Dict[str, Any]],
        seen_ids: set,
        element: WebElement,
        in_iframe: bool,
        iframe_index: Optional[int],
        in_shadow: bool,
    ) -> None:
        """
        Snapshot the element and append it to *candidates* if not seen.

        Stale elements are silently skipped.
        """
        if len(candidates) >= self.max_candidates:
            return
        try:
            eid = element.id  # internal Selenium element id
            if eid in seen_ids:
                return
            snapshot = self._snapshot(element, in_iframe, iframe_index, in_shadow)
            if snapshot:
                seen_ids.add(eid)
                candidates.append(snapshot)
        except StaleElementReferenceException:
            pass

    def _snapshot(
        self,
        element: WebElement,
        in_iframe: bool,
        iframe_index: Optional[int],
        in_shadow: bool,
    ) -> Optional[Dict[str, Any]]:
        """Return a metadata dict for *element*, or None on error."""
        try:
            tag = element.tag_name.lower()
            if tag in _SKIP_TAGS:
                return None

            text = (element.text or "").strip()
            elem_id = element.get_attribute("id") or ""
            name = element.get_attribute("name") or ""
            class_str = element.get_attribute("class") or ""
            aria_label = element.get_attribute("aria-label") or ""
            placeholder = element.get_attribute("placeholder") or ""
            role = element.get_attribute("role") or ""
            href = element.get_attribute("href") or ""
            value = element.get_attribute("value") or ""
            data_testid = element.get_attribute("data-testid") or ""

            classes = [c for c in class_str.split() if c]

            return {
                "element":       element,
                "tag":           tag,
                "text":          text,
                "id":            elem_id,
                "name":          name,
                "classes":       classes,
                "aria_label":    aria_label,
                "placeholder":   placeholder,
                "role":          role,
                "href":          href,
                "value":         value,
                "attributes": {
                    "data-testid": data_testid,
                    "role":        role,
                    "href":        href,
                    "value":       value,
                },
                "xpath":       self._generate_xpath(element, tag, elem_id, name),
                "in_iframe":   in_iframe,
                "iframe_index": iframe_index,
                "in_shadow":   in_shadow,
            }
        except (StaleElementReferenceException, WebDriverException):
            return None

    @staticmethod
    def _generate_xpath(
        element: WebElement, tag: str, elem_id: str, name: str
    ) -> str:
        """
        Build a *best-effort* xpath for the candidate.
        We prefer id-based or name-based xpaths when available.
        """
        if elem_id and not is_dynamic_identifier(elem_id):
            return f"//{tag}[@id='{elem_id}']"
        if name:
            return f"//{tag}[@name='{name}']"
        # fall back to a partial text match
        try:
            text = (element.text or "").strip()
            if text:
                safe = text.replace("'", "\\'")[:50]
                return f"//{tag}[contains(text(),'{safe}')]"
        except (StaleElementReferenceException, WebDriverException):
            pass
        return f"//{tag}"

    @staticmethod
    def _text_locators(text: str, tag: str):
        """Yield (By, expression) pairs for text-based element search."""
        safe = text.replace("'", "\\'")
        yield By.XPATH, f"//{tag}[normalize-space(text())='{safe}']"
        yield By.XPATH, f"//{tag}[contains(text(),'{safe[:30]}')]"
        yield By.XPATH, f"//{tag}[@value='{safe}']"
        yield By.XPATH, f"//{tag}[@placeholder='{safe}']"
        yield By.XPATH, f"//{tag}[@aria-label='{safe}']"


def snapshot_element(element: WebElement) -> Dict[str, Any]:
    """
    Convenience function: capture a metadata snapshot of *element* for
    storing as the baseline in ``locator_metadata.json``.

    Called by ``SelfHealingLibrary.register_locator``.
    """
    scanner = DOMScanner.__new__(DOMScanner)  # no driver needed
    # We replicate _snapshot logic without the DOMScanner instance
    try:
        tag = element.tag_name.lower()
        text = (element.text or "").strip()
        elem_id = element.get_attribute("id") or ""
        name = element.get_attribute("name") or ""
        class_str = element.get_attribute("class") or ""
        aria_label = element.get_attribute("aria-label") or ""
        placeholder = element.get_attribute("placeholder") or ""
        role = element.get_attribute("role") or ""
        data_testid = element.get_attribute("data-testid") or ""
        classes = [c for c in class_str.split() if c]
        return {
            "tag":           tag,
            "text":          text,
            "id":            elem_id,
            "name":          name,
            "classes":       classes,
            "aria_label":    aria_label,
            "placeholder":   placeholder,
            "role":          role,
            "attributes": {
                "data-testid": data_testid,
                "role":        role,
            },
        }
    except (StaleElementReferenceException, WebDriverException) as exc:
        logger.warning("Could not snapshot element: %s", exc)
        return {}
