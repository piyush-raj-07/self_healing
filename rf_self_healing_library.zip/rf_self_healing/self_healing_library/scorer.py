"""
scorer.py
---------
Combines every similarity signal into one final confidence score and
returns the best-matching candidate.

Scoring pipeline per candidate
--------------------------------
1. Compute per-attribute fuzzy scores  (similarity_engine)
2. Compute structural ancestor-path score  (similarity_engine)
3. Compute semantic embedding similarity  (embedding_matcher)
4. Apply attribute weights (configurable)
5. Penalise dynamic identifiers
6. Blend traditional weighted sum with semantic score
7. Return ranked candidates above a minimum threshold

Weight table (default)
-----------------------
Signal              Weight
---------           ------
id                  0.20   (reduced if id looks dynamic)
name                0.15
text                0.20
aria_label          0.12
placeholder         0.08
classes             0.08
tag                 0.07
data_testid         0.05
ancestor_path       0.05
---------------     -----
Subtotal            1.00

Semantic blend factor: 0.20
  final = 0.80 * weighted_traditional + 0.20 * semantic_score
"""

import logging
from typing import Any, Dict, List, Optional, Tuple

from self_healing_library.dom_scanner import is_dynamic_identifier
from self_healing_library.embedding_matcher import (
    embed_text,
    embeddings_available,
    semantic_similarity,
)
from self_healing_library.similarity_engine import (
    attribute_similarity,
    ancestor_path_score,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Default weight configuration
# ---------------------------------------------------------------------------
DEFAULT_WEIGHTS: Dict[str, float] = {
    "id":           0.20,
    "name":         0.15,
    "text":         0.20,
    "aria_label":   0.12,
    "placeholder":  0.08,
    "classes":      0.08,
    "tag":          0.07,
    "data_testid":  0.05,
    "ancestor_path": 0.05,
}

# How much the semantic embedding score contributes to the *final* score
SEMANTIC_BLEND = 0.20  # 0 = pure traditional; 1 = pure semantic

# Penalise dynamic id/name: multiply their score by this factor
DYNAMIC_ID_PENALTY = 0.30


class Scorer:
    """
    Ranks DOM candidates against stored metadata and returns the best match.

    Parameters
    ----------
    weights : dict, optional
        Override the default attribute weights.
    semantic_blend : float, optional
        How heavily the embedding similarity is blended in (0–1).
    min_confidence : float, optional
        Candidates scoring below this threshold are discarded.
    """

    def __init__(
        self,
        weights: Optional[Dict[str, float]] = None,
        semantic_blend: float = SEMANTIC_BLEND,
        min_confidence: float = 0.40,
    ):
        self.weights = weights or dict(DEFAULT_WEIGHTS)
        self.semantic_blend = semantic_blend
        self.min_confidence = min_confidence

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def score_candidates(
        self,
        stored_metadata: Dict[str, Any],
        candidates: List[Dict[str, Any]],
    ) -> List[Tuple[float, Dict[str, Any]]]:
        """
        Score every candidate against *stored_metadata*.

        Returns
        -------
        list of (confidence, candidate_dict)
            Sorted descending by confidence.  Only entries >= min_confidence
            are included.
        """
        stored_text = stored_metadata.get("text", "")
        stored_xpath = stored_metadata.get("xpath_path", "")
        stored_embedding = stored_metadata.get("embedding") or None

        # Pre-compute the reference embedding once (avoids N model calls)
        if embeddings_available() and stored_text and not stored_embedding:
            stored_embedding = embed_text(stored_text)

        results = []
        for candidate in candidates:
            confidence = self._score_one(
                stored_metadata,
                candidate,
                stored_text,
                stored_xpath,
                stored_embedding,
            )
            if confidence >= self.min_confidence:
                results.append((confidence, candidate))

        results.sort(key=lambda x: x[0], reverse=True)
        return results

    def best_match(
        self,
        stored_metadata: Dict[str, Any],
        candidates: List[Dict[str, Any]],
    ) -> Tuple[Optional[float], Optional[Dict[str, Any]]]:
        """
        Return (confidence, best_candidate) or (None, None) if no match
        exceeds min_confidence.
        """
        ranked = self.score_candidates(stored_metadata, candidates)
        if ranked:
            return ranked[0]
        return None, None

    # ------------------------------------------------------------------
    # Per-candidate scoring
    # ------------------------------------------------------------------

    def _score_one(
        self,
        stored: Dict[str, Any],
        candidate: Dict[str, Any],
        stored_text: str,
        stored_xpath: str,
        stored_embedding: Optional[List[float]],
    ) -> float:
        """Compute the final confidence score for a single candidate."""

        # 1. Per-attribute fuzzy scores
        attr_scores = attribute_similarity(stored, candidate)

        # 2. Ancestor path score
        cand_xpath = candidate.get("xpath", "")
        attr_scores["ancestor_path"] = ancestor_path_score(stored_xpath, cand_xpath)

        # 3. Dynamic-id penalty
        cand_id = candidate.get("id", "")
        cand_name = candidate.get("name", "")
        id_weight = self.weights["id"]
        name_weight = self.weights["name"]
        if cand_id and is_dynamic_identifier(cand_id):
            id_weight *= DYNAMIC_ID_PENALTY
        if cand_name and is_dynamic_identifier(cand_name):
            name_weight *= DYNAMIC_ID_PENALTY

        # 4. Weighted traditional score
        adjusted_weights = {**self.weights, "id": id_weight, "name": name_weight}
        total_weight = sum(adjusted_weights.values())
        traditional = sum(
            adjusted_weights.get(key, 0.0) * score
            for key, score in attr_scores.items()
        )
        if total_weight > 0:
            traditional /= total_weight

        # 5. Semantic embedding score
        cand_text = candidate.get("text", "")
        sem_score = semantic_similarity(stored_text, cand_text, stored_embedding)

        # 6. Blend
        if embeddings_available() and (stored_text or cand_text):
            final = (
                (1.0 - self.semantic_blend) * traditional
                + self.semantic_blend * sem_score
            )
        else:
            final = traditional

        return round(min(1.0, max(0.0, final)), 4)

    # ------------------------------------------------------------------
    # Score explanation (useful for debugging / logging)
    # ------------------------------------------------------------------

    def explain(
        self,
        stored_metadata: Dict[str, Any],
        candidate: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Return a detailed breakdown of the scoring for a single candidate.
        Useful when debugging why a particular element was (or wasn't) chosen.
        """
        stored_text = stored_metadata.get("text", "")
        stored_xpath = stored_metadata.get("xpath_path", "")
        stored_embedding = stored_metadata.get("embedding") or None

        attr_scores = attribute_similarity(stored_metadata, candidate)
        attr_scores["ancestor_path"] = ancestor_path_score(
            stored_xpath, candidate.get("xpath", "")
        )
        cand_text = candidate.get("text", "")
        sem_score = semantic_similarity(stored_text, cand_text, stored_embedding)

        confidence = self._score_one(
            stored_metadata, candidate, stored_text, stored_xpath, stored_embedding
        )

        return {
            "confidence":   confidence,
            "attr_scores":  attr_scores,
            "semantic":     sem_score,
            "candidate_tag": candidate.get("tag"),
            "candidate_text": cand_text,
            "candidate_id": candidate.get("id"),
        }
