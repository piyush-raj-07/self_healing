"""
similarity_engine.py
--------------------
Fuzzy / string-similarity comparisons between stored metadata and live
DOM candidates.

This module intentionally has *no* heavy ML dependencies – it uses only
the standard library plus the lightweight ``rapidfuzz`` package (which
gracefully falls back to ``difflib`` if unavailable).

Exported helpers
----------------
text_similarity(a, b)         -> float  0–1
attribute_similarity(meta, cand) -> dict  per-attribute scores
class_overlap_score(a, b)     -> float  Jaccard coefficient
ancestor_path_score(a, b)     -> float  edit-distance on xpath tokens
"""

import logging
import re
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Fuzzy backend (rapidfuzz preferred for speed; difflib as fallback)
# ---------------------------------------------------------------------------
try:
    from rapidfuzz import fuzz as _fuzz
    from rapidfuzz import process as _process

    def _ratio(a: str, b: str) -> float:
        return _fuzz.ratio(a, b) / 100.0

    def _partial_ratio(a: str, b: str) -> float:
        return _fuzz.partial_ratio(a, b) / 100.0

    def _token_sort(a: str, b: str) -> float:
        return _fuzz.token_sort_ratio(a, b) / 100.0

    logger.debug("similarity_engine: using rapidfuzz backend")

except ImportError:
    import difflib

    def _ratio(a: str, b: str) -> float:
        return difflib.SequenceMatcher(None, a.lower(), b.lower()).ratio()

    def _partial_ratio(a: str, b: str) -> float:
        # Approximate partial ratio: slide the shorter string over the longer
        if not a or not b:
            return 0.0
        short, long_ = (a, b) if len(a) <= len(b) else (b, a)
        best = 0.0
        for i in range(len(long_) - len(short) + 1):
            s = difflib.SequenceMatcher(
                None, short.lower(), long_[i : i + len(short)].lower()
            ).ratio()
            if s > best:
                best = s
        return best

    def _token_sort(a: str, b: str) -> float:
        ta = " ".join(sorted(a.lower().split()))
        tb = " ".join(sorted(b.lower().split()))
        return difflib.SequenceMatcher(None, ta, tb).ratio()

    logger.debug("similarity_engine: rapidfuzz not found – using difflib fallback")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def text_similarity(a: str, b: str) -> float:
    """
    Composite text similarity score (0–1) combining three fuzzy measures:
      - Exact ratio (most precise)
      - Partial ratio (handles substrings, e.g. 'Login' inside 'Login Now')
      - Token-sort ratio (handles word reordering, e.g. 'Sign In' vs 'In Sign')

    The weights are tuned to prioritise exact matches while still catching
    common label variations.
    """
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    a, b = a.strip().lower(), b.strip().lower()
    if a == b:
        return 1.0
    exact  = _ratio(a, b)
    partial = _partial_ratio(a, b)
    token  = _token_sort(a, b)
    return round(0.4 * exact + 0.35 * partial + 0.25 * token, 4)


def attribute_similarity(
    stored: Dict[str, Any], candidate: Dict[str, Any]
) -> Dict[str, float]:
    """
    Compare individual attributes of the stored metadata against a live
    candidate element and return per-attribute similarity scores.

    Parameters
    ----------
    stored : dict
        Metadata dict from locator_metadata.json.
    candidate : dict
        Candidate dict produced by DOMScanner._snapshot().

    Returns
    -------
    dict
        Keys: "id", "name", "text", "aria_label", "placeholder", "tag",
              "classes", "data_testid"
        Values: float 0–1
    """
    scores: Dict[str, float] = {}

    # --- tag (exact, but some substitutions are valid, e.g. div vs span) ---
    st, ct = stored.get("tag", ""), candidate.get("tag", "")
    scores["tag"] = 1.0 if st == ct else (0.5 if {st, ct} <= {"div", "span"} else 0.0)

    # --- id ---
    si, ci = stored.get("id", ""), candidate.get("id", "")
    if si and ci:
        scores["id"] = _ratio(si, ci)
    elif not si and not ci:
        scores["id"] = 0.5  # neither has an id → neutral
    else:
        scores["id"] = 0.0

    # --- name ---
    sn, cn = stored.get("name", ""), candidate.get("name", "")
    scores["name"] = text_similarity(sn, cn)

    # --- visible text ---
    scores["text"] = text_similarity(
        stored.get("text", ""), candidate.get("text", "")
    )

    # --- aria-label ---
    scores["aria_label"] = text_similarity(
        stored.get("aria_label", ""), candidate.get("aria_label", "")
    )

    # --- placeholder ---
    scores["placeholder"] = text_similarity(
        stored.get("placeholder", ""), candidate.get("placeholder", "")
    )

    # --- data-testid (exact match preferred) ---
    std = stored.get("attributes", {}).get("data-testid", "")
    ctd = candidate.get("attributes", {}).get("data-testid", "")
    if std and ctd:
        scores["data_testid"] = 1.0 if std == ctd else _ratio(std, ctd)
    else:
        scores["data_testid"] = 0.0

    # --- CSS classes (Jaccard) ---
    scores["classes"] = class_overlap_score(
        stored.get("classes", []), candidate.get("classes", [])
    )

    return scores


def class_overlap_score(a: List[str], b: List[str]) -> float:
    """
    Jaccard similarity coefficient for two sets of CSS class names.

    Dynamic-looking class names (e.g. "abc123", "_xyz_9f2e") are filtered
    out before comparison because they change between page renders.
    """
    from self_healing_library.dom_scanner import is_dynamic_identifier

    def _stable(classes):
        return {c for c in classes if not is_dynamic_identifier(c)}

    sa, sb = _stable(a), _stable(b)
    if not sa and not sb:
        return 0.5  # both empty → neutral
    if not sa or not sb:
        return 0.0
    intersection = sa & sb
    union = sa | sb
    return round(len(intersection) / len(union), 4)


def ancestor_path_score(stored_xpath: str, candidate_xpath: str) -> float:
    """
    Structural path similarity based on the *ancestor* portion of an xpath.

    We tokenize each xpath into path segments, ignore dynamic indices like
    [2], and measure token-level Jaccard similarity.

    e.g. "//div[@id='main']/form/button" and "//div[@id='main']/form/input"
    share 2 of 3 segments → 0.67
    """
    if not stored_xpath or not candidate_xpath:
        return 0.0

    def _tokens(xpath: str) -> List[str]:
        # Strip indices like [1], [2], and split on /
        clean = re.sub(r"\[\d+\]", "", xpath)
        parts = [p for p in clean.split("/") if p]
        # Keep only the tag part of each step (drop predicates)
        return [re.split(r"[\[\(]", p)[0] for p in parts]

    ta = set(_tokens(stored_xpath))
    tc = set(_tokens(candidate_xpath))
    if not ta or not tc:
        return 0.0
    return round(len(ta & tc) / len(ta | tc), 4)
