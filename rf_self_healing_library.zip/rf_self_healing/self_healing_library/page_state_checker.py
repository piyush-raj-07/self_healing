"""
page_state_checker.py
---------------------
Pre-healing checks that guard against acting on a page that is not ready.

Checks performed (in order)
----------------------------
1. Page load complete     – document.readyState === 'complete'
2. Loader / spinner gone  – configurable CSS selectors hidden/absent
3. Popup / overlay closed – checks for modal backdrops
4. Element visible        – offsetParent, visibility, opacity
5. Element enabled        – disabled attribute / aria-disabled
6. Scroll into view       – scrollIntoView if needed
"""

import logging
import time
from typing import List, Optional

from selenium.common.exceptions import (
    JavascriptException,
    StaleElementReferenceException,
    WebDriverException,
)
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

logger = logging.getLogger(__name__)

# Default CSS selectors that indicate a loading overlay is active
DEFAULT_LOADER_SELECTORS = [
    ".loading",
    ".loader",
    ".spinner",
    "[class*='loading']",
    "[class*='spinner']",
    "[data-loading='true']",
    ".overlay-loading",
]

# Selectors for modal backdrops / popups
DEFAULT_POPUP_SELECTORS = [
    ".modal-backdrop",
    ".modal.show",
    "[class*='overlay']",
    ".popup",
    ".dialog",
    "[role='dialog']",
    "[aria-modal='true']",
]


class PageStateChecker:
    """
    Validates that the page (and the target element) are in a ready state
    before the self-healing engine attempts to interact with them.

    Parameters
    ----------
    driver : WebDriver
        Active Selenium WebDriver.
    page_ready_timeout : float
        Seconds to wait for page-load checks.
    loader_selectors : list[str], optional
        CSS selectors that indicate a loading spinner.  Overrides defaults.
    popup_selectors : list[str], optional
        CSS selectors that indicate an obstructing popup.  Overrides defaults.
    """

    def __init__(
        self,
        driver: WebDriver,
        page_ready_timeout: float = 10.0,
        loader_selectors: Optional[List[str]] = None,
        popup_selectors: Optional[List[str]] = None,
    ):
        self.driver = driver
        self.timeout = page_ready_timeout
        self.loader_selectors = loader_selectors or DEFAULT_LOADER_SELECTORS
        self.popup_selectors = popup_selectors or DEFAULT_POPUP_SELECTORS

    # ------------------------------------------------------------------
    # Page-level checks
    # ------------------------------------------------------------------

    def wait_for_page_ready(self) -> bool:
        """
        Block until ``document.readyState === 'complete'``.

        Returns True if the page is ready within *timeout* seconds.
        """
        deadline = time.time() + self.timeout
        while time.time() < deadline:
            try:
                state = self.driver.execute_script("return document.readyState")
                if state == "complete":
                    return True
            except JavascriptException:
                pass
            time.sleep(0.25)
        logger.warning("Page did not reach readyState='complete' within %.1fs", self.timeout)
        return False

    def wait_for_loaders_gone(self) -> bool:
        """
        Wait until all known loading spinners/overlays are hidden or absent.

        Returns True if no loaders are visible; False on timeout.
        """
        deadline = time.time() + self.timeout
        while time.time() < deadline:
            if not self._any_visible(self.loader_selectors):
                return True
            time.sleep(0.3)
        logger.warning("Loaders still visible after %.1fs", self.timeout)
        return False  # non-fatal – we continue anyway

    def check_for_popups(self) -> bool:
        """
        Return True if a blocking popup/modal is currently shown.
        Callers can decide whether to fail or attempt to dismiss it.
        """
        return self._any_visible(self.popup_selectors)

    # ------------------------------------------------------------------
    # Element-level checks
    # ------------------------------------------------------------------

    def is_element_visible(self, element: WebElement) -> bool:
        """Return True if *element* is rendered and visible in the viewport."""
        try:
            js = """
            const el = arguments[0];
            if (!el.offsetParent && el.tagName !== 'BODY') return false;
            const style = window.getComputedStyle(el);
            if (style.visibility === 'hidden') return false;
            if (parseFloat(style.opacity) === 0) return false;
            if (style.display === 'none') return false;
            return true;
            """
            return bool(self.driver.execute_script(js, element))
        except (JavascriptException, StaleElementReferenceException, WebDriverException):
            return False

    def is_element_enabled(self, element: WebElement) -> bool:
        """Return True if *element* is not disabled."""
        try:
            disabled = element.get_attribute("disabled")
            aria_disabled = element.get_attribute("aria-disabled")
            if disabled in ("true", "disabled", ""):
                return False
            if aria_disabled == "true":
                return False
            return element.is_enabled()
        except (StaleElementReferenceException, WebDriverException):
            return False

    def scroll_into_view(self, element: WebElement) -> None:
        """Scroll *element* into the browser viewport."""
        try:
            self.driver.execute_script(
                "arguments[0].scrollIntoView({block:'center', behavior:'smooth'});",
                element,
            )
            time.sleep(0.3)  # brief pause for smooth scroll animation
        except (JavascriptException, StaleElementReferenceException, WebDriverException) as exc:
            logger.debug("scroll_into_view failed: %s", exc)

    def wait_for_element_visible(
        self, element: WebElement, timeout: Optional[float] = None
    ) -> bool:
        """
        Poll until *element* is visible, up to *timeout* seconds.
        Returns True if it becomes visible in time.
        """
        deadline = time.time() + (timeout or self.timeout)
        while time.time() < deadline:
            if self.is_element_visible(element):
                return True
            time.sleep(0.2)
        return False

    def wait_for_element_enabled(
        self, element: WebElement, timeout: Optional[float] = None
    ) -> bool:
        """
        Poll until *element* is enabled, up to *timeout* seconds.
        """
        deadline = time.time() + (timeout or self.timeout)
        while time.time() < deadline:
            if self.is_element_enabled(element):
                return True
            time.sleep(0.2)
        return False

    # ------------------------------------------------------------------
    # Composite pre-action check
    # ------------------------------------------------------------------

    def prepare_element(
        self, element: WebElement, scroll: bool = True
    ) -> bool:
        """
        Run the full pre-action checklist for *element*:
          1. Scroll into view (optional)
          2. Wait for visible
          3. Wait for enabled

        Returns True if the element is ready to interact with.
        """
        if scroll:
            self.scroll_into_view(element)
        if not self.wait_for_element_visible(element, timeout=5.0):
            logger.warning("Element is not visible after scrolling")
            return False
        if not self.wait_for_element_enabled(element, timeout=5.0):
            logger.warning("Element is not enabled")
            return False
        return True

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _any_visible(self, selectors: List[str]) -> bool:
        """Return True if any element matched by *selectors* is currently shown."""
        for selector in selectors:
            try:
                elements = self.driver.find_elements(
                    "css selector", selector  # type: ignore[arg-type]
                )
                for el in elements:
                    if el.is_displayed():
                        return True
            except WebDriverException:
                pass
        return False
